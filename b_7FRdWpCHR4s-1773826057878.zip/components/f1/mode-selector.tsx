'use client'

import { Headphones, Users, Play, LayoutDashboard, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'

export type DashboardMode = 'dashboard' | 'engineer' | 'fan' | 'simulation'

interface ModeSelectorProps {
  currentMode: DashboardMode
  onModeChange: (mode: DashboardMode) => void
  className?: string
}

const modes = [
  {
    id: 'dashboard' as DashboardMode,
    label: 'RACE CONTROL',
    icon: LayoutDashboard,
    activeColor: 'bg-f1-white text-background',
    activeBorder: 'border-f1-white',
    activeGlow: 'glow-white',
    iconColor: 'text-f1-white',
    description: 'Full telemetry',
  },
  {
    id: 'engineer' as DashboardMode,
    label: 'ENGINEER',
    icon: Headphones,
    activeColor: 'bg-f1-red text-white',
    activeBorder: 'border-f1-red',
    activeGlow: 'glow-red',
    iconColor: 'text-f1-red',
    description: 'Voice & AI',
  },
  {
    id: 'fan' as DashboardMode,
    label: 'FAN MODE',
    icon: Users,
    activeColor: 'bg-f1-cyan text-background',
    activeBorder: 'border-f1-cyan',
    activeGlow: 'glow-cyan',
    iconColor: 'text-f1-cyan',
    description: 'Battles',
  },
  {
    id: 'simulation' as DashboardMode,
    label: 'SIMULATION',
    icon: Play,
    activeColor: 'bg-f1-silver text-background',
    activeBorder: 'border-f1-silver',
    activeGlow: '',
    iconColor: 'text-f1-silver',
    description: 'Replay & AI',
  },
]

export function ModeSelector({ currentMode, onModeChange, className }: ModeSelectorProps) {
  return (
    <div className={cn('flex gap-1 p-1 glass-panel rounded-sm', className)}>
      {modes.map((mode) => {
        const Icon = mode.icon
        const isActive = currentMode === mode.id

        return (
          <button
            key={mode.id}
            onClick={() => onModeChange(mode.id)}
            className={cn(
              'group relative flex items-center gap-2 px-4 py-2.5 rounded-sm transition-all duration-300',
              'border border-transparent',
              isActive 
                ? `${mode.activeColor} ${mode.activeBorder} ${mode.activeGlow}` 
                : 'hover:bg-glass-white text-f1-silver/70 hover:text-f1-white'
            )}
          >
            <Icon className={cn(
              'h-4 w-4 transition-colors',
              isActive ? '' : mode.iconColor
            )} />
            <div className="hidden sm:block text-left">
              <span className="text-[10px] font-black hud-text block tracking-widest">{mode.label}</span>
              <span className={cn(
                'text-[9px] font-medium',
                isActive ? 'opacity-70' : 'text-f1-silver/40'
              )}>
                {mode.description}
              </span>
            </div>
            {isActive && (
              <ChevronRight className="h-3 w-3 ml-1 hidden sm:block" />
            )}
          </button>
        )
      })}
    </div>
  )
}
