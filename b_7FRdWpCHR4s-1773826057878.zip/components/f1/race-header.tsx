'use client'

import { Flag, Cloud, Thermometer, Wind, Droplets, Timer, Radio } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { SessionData, FlagStatus } from '@/lib/f1-data'

interface RaceHeaderProps {
  session: SessionData
  className?: string
}

function getFlagDisplay(flag: FlagStatus) {
  const config: Record<FlagStatus, { color: string; text: string; glow: string; textColor: string }> = {
    green: { color: 'bg-f1-green', text: 'GREEN FLAG', glow: 'glow-green', textColor: 'text-background' },
    yellow: { color: 'bg-f1-yellow', text: 'YELLOW FLAG', glow: 'glow-yellow', textColor: 'text-background' },
    red: { color: 'bg-f1-red', text: 'RED FLAG', glow: 'glow-red', textColor: 'text-white' },
    'safety-car': { color: 'bg-f1-yellow', text: 'SAFETY CAR', glow: 'glow-yellow', textColor: 'text-background' },
    vsc: { color: 'bg-f1-yellow', text: 'VSC DEPLOYED', glow: 'glow-yellow', textColor: 'text-background' },
    checkered: { color: 'bg-f1-white', text: 'CHECKERED', glow: 'glow-white', textColor: 'text-background' },
  }
  return config[flag]
}

export function RaceHeader({ session, className }: RaceHeaderProps) {
  const flagDisplay = getFlagDisplay(session.flag)

  return (
    <header className={cn('glass-panel hud-frame rounded-lg p-5', className)}>
      <div className="flex items-center justify-between gap-6 flex-wrap">
        {/* F1 Logo & Session */}
        <div className="flex items-center gap-8">
          {/* F1 Branding */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="text-3xl font-black tracking-tighter text-f1-white cinematic-title">
                F<span className="text-f1-red">1</span>
              </div>
              <div className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-f1-red via-f1-red to-transparent" />
            </div>
            <div className="w-px h-10 bg-border" />
          </div>
          
          {/* Session Info */}
          <div className="flex flex-col">
            <span className="text-[10px] text-f1-silver/60 hud-text">SESSION TYPE</span>
            <span className="text-xl font-black text-f1-white cinematic-title">{session.type}</span>
          </div>
          
          <div className="h-10 w-px bg-border hidden sm:block" />
          
          <div className="flex flex-col hidden sm:flex">
            <span className="text-[10px] text-f1-silver/60 hud-text">CIRCUIT</span>
            <span className="text-xl font-black text-f1-white cinematic-title">{session.track}</span>
          </div>
          
          <div className="h-10 w-px bg-border hidden md:block" />
          
          {/* Lap Counter */}
          <div className="flex flex-col hidden md:flex">
            <span className="text-[10px] text-f1-silver/60 hud-text">LAP</span>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-black text-f1-white hud-number">{session.currentLap}</span>
              <span className="text-lg text-f1-silver/40 font-medium">/</span>
              <span className="text-lg text-f1-silver/60 hud-number">{session.totalLaps}</span>
            </div>
          </div>
        </div>

        {/* Flag Status */}
        <div className={cn(
          'flex items-center gap-3 px-5 py-2.5 rounded-sm',
          flagDisplay.color, 
          flagDisplay.glow
        )}>
          <Flag className={cn('h-5 w-5', flagDisplay.textColor)} />
          <span className={cn('font-black hud-text text-sm tracking-widest', flagDisplay.textColor)}>
            {flagDisplay.text}
          </span>
        </div>

        {/* Weather Panel */}
        <div className="flex items-center gap-5 glass-panel-light rounded-sm px-4 py-2">
          <div className="flex items-center gap-2">
            <Thermometer className="h-4 w-4 text-f1-red" />
            <div className="flex flex-col">
              <span className="text-[9px] text-f1-silver/50 hud-text">AIR</span>
              <span className="text-sm font-bold text-f1-white hud-number">{session.weather.airTemp}°</span>
            </div>
          </div>
          
          <div className="w-px h-8 bg-border" />
          
          <div className="flex items-center gap-2">
            <Thermometer className="h-4 w-4 text-f1-orange" />
            <div className="flex flex-col">
              <span className="text-[9px] text-f1-silver/50 hud-text">TRACK</span>
              <span className="text-sm font-bold text-f1-white hud-number">{session.weather.trackTemp}°</span>
            </div>
          </div>
          
          <div className="w-px h-8 bg-border hidden lg:block" />
          
          <div className="flex items-center gap-2 hidden lg:flex">
            <Wind className="h-4 w-4 text-f1-cyan" />
            <div className="flex flex-col">
              <span className="text-[9px] text-f1-silver/50 hud-text">WIND</span>
              <span className="text-sm font-bold text-f1-white hud-number">{session.weather.wind} <span className="text-f1-silver/50 text-xs">{session.weather.windDirection}</span></span>
            </div>
          </div>
          
          <div className="w-px h-8 bg-border hidden xl:block" />
          
          <div className="flex items-center gap-2 hidden xl:flex">
            <Droplets className="h-4 w-4 text-f1-cyan" />
            <div className="flex flex-col">
              <span className="text-[9px] text-f1-silver/50 hud-text">HUMIDITY</span>
              <span className="text-sm font-bold text-f1-white hud-number">{session.weather.humidity}%</span>
            </div>
          </div>
        </div>

        {/* Live Timer */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-f1-red">
            <Radio className="h-4 w-4 animate-pulse" />
            <span className="text-[10px] hud-text">LIVE</span>
          </div>
          <div className="glass-panel-light rounded-sm px-4 py-2">
            <span className="text-3xl font-black text-f1-white hud-number tracking-wider animate-pulse-glow">
              {session.timeRemaining}
            </span>
          </div>
        </div>
      </div>
    </header>
  )
}
