'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Play, Pause, SkipBack, SkipForward, RefreshCw, Brain, TrendingUp, Percent, ChevronRight, FastForward, Cpu } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, AreaChart, Area, Tooltip, Legend, BarChart, Bar, Cell } from 'recharts'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { cn } from '@/lib/utils'
import type { Driver, TelemetryPoint } from '@/lib/f1-data'

interface SimulationModeProps {
  drivers: Driver[]
  historicalLaps: TelemetryPoint[][]
  className?: string
}

interface PredictionResult {
  driverId: string
  driverCode: string
  teamColor: string
  currentPosition: number
  predictedPosition: number
  winProbability: number
  podiumProbability: number
  pointsProbability: number
  factors: string[]
}

// Generate AI predictions based on current race state
function generatePredictions(drivers: Driver[]): PredictionResult[] {
  return drivers.slice(0, 10).map((driver, index) => {
    const baseWinProb = Math.max(0, 100 - index * 15 - Math.random() * 10)
    const podiumProb = Math.min(100, baseWinProb + 30 + Math.random() * 20)
    const pointsProb = Math.min(100, podiumProb + 40 + Math.random() * 20)

    // Predict slight position changes
    let predictedPosition = driver.position
    if (Math.random() > 0.7) {
      predictedPosition = Math.max(1, Math.min(20, predictedPosition + (Math.random() > 0.5 ? 1 : -1)))
    }

    const factors: string[] = []
    if (driver.delta < 0) factors.push('Strong current pace')
    if (driver.tyreAge < 10) factors.push('Fresh tyres')
    if (driver.ers > 70) factors.push('Good ERS deployment')
    if (driver.fuel < 30) factors.push('Light fuel load')
    if (driver.tyreWear.fr > 50) factors.push('High tyre wear')
    if (driver.position <= 3) factors.push('Track position advantage')

    return {
      driverId: driver.id,
      driverCode: driver.code,
      teamColor: driver.teamColor,
      currentPosition: driver.position,
      predictedPosition,
      winProbability: Math.round(baseWinProb),
      podiumProbability: Math.round(podiumProb),
      pointsProbability: Math.round(pointsProb),
      factors: factors.slice(0, 3),
    }
  })
}

function ReplayControls({ 
  isPlaying, 
  onPlayPause, 
  onReset, 
  currentLap, 
  maxLap,
  onLapChange,
  playbackSpeed,
  onSpeedChange,
}: {
  isPlaying: boolean
  onPlayPause: () => void
  onReset: () => void
  currentLap: number
  maxLap: number
  onLapChange: (lap: number) => void
  playbackSpeed: number
  onSpeedChange: (speed: number) => void
}) {
  return (
    <div className="glass-panel hud-frame rounded-sm p-5">
      <div className="flex items-center justify-between mb-5">
        <h3 className="text-xs font-black text-f1-white hud-text tracking-widest">LAP REPLAY</h3>
        <div className="flex items-center gap-2">
          <span className="text-[9px] text-f1-silver/50 hud-text">SPEED</span>
          {[0.5, 1, 2, 4].map((speed) => (
            <button
              key={speed}
              onClick={() => onSpeedChange(speed)}
              className={cn(
                'text-[10px] px-3 py-1.5 rounded-sm font-bold transition-all',
                playbackSpeed === speed 
                  ? 'bg-f1-cyan text-background' 
                  : 'bg-muted text-f1-silver/60 hover:bg-muted/80'
              )}
            >
              {speed}x
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-5">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={onReset}
          className="rounded-sm border-border hover:bg-glass-white"
        >
          <SkipBack className="h-4 w-4" />
        </Button>
        <Button 
          size="icon" 
          onClick={onPlayPause}
          className={cn(
            'rounded-sm w-12 h-12',
            isPlaying 
              ? 'bg-f1-red hover:bg-f1-red/80 glow-red' 
              : 'bg-f1-green hover:bg-f1-green/80 glow-green'
          )}
        >
          {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
        </Button>
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => onLapChange(Math.min(maxLap, currentLap + 1))}
          className="rounded-sm border-border hover:bg-glass-white"
        >
          <SkipForward className="h-4 w-4" />
        </Button>

        <div className="flex-1 flex items-center gap-4">
          <span className="text-sm font-black text-f1-white hud-number">LAP {currentLap}</span>
          <Slider
            value={[currentLap]}
            min={1}
            max={maxLap}
            step={1}
            onValueChange={([lap]) => onLapChange(lap)}
            className="flex-1"
          />
          <span className="text-sm font-mono text-f1-silver/50">LAP {maxLap}</span>
        </div>
      </div>
    </div>
  )
}

function TelemetryReplay({ 
  data, 
  currentIndex 
}: { 
  data: TelemetryPoint[]
  currentIndex: number 
}) {
  const visibleData = data.slice(0, currentIndex + 1)

  return (
    <div className="glass-panel hud-frame rounded-sm p-5">
      <h3 className="text-xs font-black text-f1-white hud-text tracking-widest mb-4">TELEMETRY REPLAY</h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Speed trace */}
        <div className="glass-panel-light rounded-sm p-4">
          <p className="text-[9px] text-f1-silver/50 hud-text mb-3">SPEED (KM/H)</p>
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={visibleData}>
                <defs>
                  <linearGradient id="speedGradReplayCinematic" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.78 0.14 195)" stopOpacity={0.5}/>
                    <stop offset="95%" stopColor="oklch(0.78 0.14 195)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="distance" hide />
                <YAxis domain={[100, 350]} hide />
                <Area 
                  type="monotone" 
                  dataKey="speed" 
                  stroke="oklch(0.78 0.14 195)" 
                  strokeWidth={2}
                  fill="url(#speedGradReplayCinematic)" 
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Throttle/Brake */}
        <div className="glass-panel-light rounded-sm p-4">
          <p className="text-[9px] text-f1-silver/50 hud-text mb-3">THROTTLE / BRAKE</p>
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={visibleData}>
                <XAxis dataKey="distance" hide />
                <YAxis domain={[0, 100]} hide />
                <Area 
                  type="monotone" 
                  dataKey="throttle" 
                  stroke="oklch(0.7 0.18 145)" 
                  strokeWidth={2}
                  fill="oklch(0.7 0.18 145 / 0.2)" 
                  isAnimationActive={false}
                />
                <Area 
                  type="monotone" 
                  dataKey="brake" 
                  stroke="oklch(0.58 0.24 25)" 
                  strokeWidth={2}
                  fill="oklch(0.58 0.24 25 / 0.2)" 
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Current values */}
      {visibleData.length > 0 && (
        <div className="mt-5 grid grid-cols-4 gap-3">
          <div className="glass-panel-light rounded-sm p-3 text-center">
            <span className="text-[9px] text-f1-silver/50 hud-text">SPEED</span>
            <p className="text-2xl font-black text-f1-cyan hud-number mt-1">
              {Math.round(visibleData[visibleData.length - 1].speed)}
            </p>
          </div>
          <div className="glass-panel-light rounded-sm p-3 text-center">
            <span className="text-[9px] text-f1-silver/50 hud-text">THROTTLE</span>
            <p className="text-2xl font-black text-f1-green hud-number mt-1">
              {Math.round(visibleData[visibleData.length - 1].throttle)}%
            </p>
          </div>
          <div className="glass-panel-light rounded-sm p-3 text-center">
            <span className="text-[9px] text-f1-silver/50 hud-text">BRAKE</span>
            <p className="text-2xl font-black text-f1-red hud-number mt-1">
              {Math.round(visibleData[visibleData.length - 1].brake)}%
            </p>
          </div>
          <div className="glass-panel-light rounded-sm p-3 text-center">
            <span className="text-[9px] text-f1-silver/50 hud-text">GEAR</span>
            <p className="text-2xl font-black text-f1-white hud-number mt-1">
              {visibleData[visibleData.length - 1].gear}
            </p>
          </div>
        </div>
      )}
    </div>
  )
}

function PredictionCard({ prediction }: { prediction: PredictionResult }) {
  const positionChange = prediction.currentPosition - prediction.predictedPosition

  return (
    <div className="glass-panel-light rounded-sm p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div 
            className="w-1.5 h-10 rounded-full"
            style={{ backgroundColor: prediction.teamColor, boxShadow: `0 0 10px ${prediction.teamColor}60` }}
          />
          <div>
            <span className="font-black text-xl text-f1-white">{prediction.driverCode}</span>
            <div className="flex items-center gap-1.5 text-[10px] mt-0.5">
              <span className="text-f1-silver/50">P{prediction.currentPosition}</span>
              {positionChange !== 0 && (
                <>
                  <ChevronRight className="h-3 w-3 text-f1-silver/30" />
                  <span className={cn(
                    'font-bold',
                    positionChange > 0 ? 'text-f1-green' : 'text-f1-red'
                  )}>
                    P{prediction.predictedPosition}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
        <div className="text-right">
          <span className="text-3xl font-black text-f1-yellow hud-number">
            {prediction.winProbability}<span className="text-lg text-f1-silver/50">%</span>
          </span>
          <span className="text-[9px] text-f1-silver/50 block hud-text">WIN PROB</span>
        </div>
      </div>

      {/* Probability bars */}
      <div className="space-y-2.5">
        <div>
          <div className="flex justify-between text-[10px] mb-1">
            <span className="text-f1-silver/50 hud-text">PODIUM</span>
            <span className="font-bold text-f1-orange hud-number">{prediction.podiumProbability}%</span>
          </div>
          <div className="h-1.5 bg-muted rounded-sm overflow-hidden">
            <div 
              className="h-full bg-f1-orange transition-all duration-500 rounded-sm"
              style={{ width: `${prediction.podiumProbability}%`, boxShadow: '0 0 8px oklch(0.72 0.18 55 / 0.5)' }}
            />
          </div>
        </div>
        <div>
          <div className="flex justify-between text-[10px] mb-1">
            <span className="text-f1-silver/50 hud-text">POINTS</span>
            <span className="font-bold text-f1-green hud-number">{prediction.pointsProbability}%</span>
          </div>
          <div className="h-1.5 bg-muted rounded-sm overflow-hidden">
            <div 
              className="h-full bg-f1-green transition-all duration-500 rounded-sm"
              style={{ width: `${prediction.pointsProbability}%`, boxShadow: '0 0 8px oklch(0.7 0.18 145 / 0.5)' }}
            />
          </div>
        </div>
      </div>

      {/* Key factors */}
      {prediction.factors.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {prediction.factors.map((factor, i) => (
            <span 
              key={i}
              className="text-[9px] px-2 py-1 rounded-sm bg-muted text-f1-silver/60"
            >
              {factor}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

function WinProbabilityChart({ predictions }: { predictions: PredictionResult[] }) {
  const data = predictions.slice(0, 6).map(p => ({
    name: p.driverCode,
    probability: p.winProbability,
    color: p.teamColor,
  }))

  return (
    <div className="glass-panel-light rounded-sm p-4">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="h-4 w-4 text-f1-cyan" />
        <h3 className="text-xs font-black text-f1-white hud-text tracking-widest">WIN PROBABILITY</h3>
      </div>
      <div className="h-52">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical">
            <XAxis type="number" domain={[0, 100]} hide />
            <YAxis 
              type="category" 
              dataKey="name" 
              width={45} 
              tick={{ fill: 'oklch(0.85 0.01 260)', fontSize: 11, fontWeight: 'bold' }} 
            />
            <Bar dataKey="probability" radius={[0, 4, 4, 0]}>
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.color}
                  style={{ filter: `drop-shadow(0 0 6px ${entry.color}60)` }}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export function SimulationMode({ drivers, historicalLaps, className }: SimulationModeProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentLap, setCurrentLap] = useState(1)
  const [currentDataIndex, setCurrentDataIndex] = useState(0)
  const [playbackSpeed, setPlaybackSpeed] = useState(1)
  const [predictions, setPredictions] = useState<PredictionResult[]>([])
  const [isGeneratingPredictions, setIsGeneratingPredictions] = useState(false)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  const maxLap = historicalLaps.length
  const currentLapData = historicalLaps[currentLap - 1] || []

  // Generate initial predictions
  useEffect(() => {
    setPredictions(generatePredictions(drivers))
  }, [drivers])

  // Playback logic
  useEffect(() => {
    if (isPlaying && currentLapData.length > 0) {
      intervalRef.current = setInterval(() => {
        setCurrentDataIndex(prev => {
          if (prev >= currentLapData.length - 1) {
            if (currentLap < maxLap) {
              setCurrentLap(l => l + 1)
              return 0
            } else {
              setIsPlaying(false)
              return prev
            }
          }
          return prev + 1
        })
      }, 100 / playbackSpeed)
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isPlaying, playbackSpeed, currentLapData.length, currentLap, maxLap])

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  const handleReset = () => {
    setIsPlaying(false)
    setCurrentLap(1)
    setCurrentDataIndex(0)
  }

  const handleLapChange = (lap: number) => {
    setCurrentLap(lap)
    setCurrentDataIndex(0)
  }

  const regeneratePredictions = useCallback(() => {
    setIsGeneratingPredictions(true)
    setTimeout(() => {
      setPredictions(generatePredictions(drivers))
      setIsGeneratingPredictions(false)
    }, 1500)
  }, [drivers])

  return (
    <div className={cn('flex flex-col gap-4 h-full overflow-y-auto', className)}>
      {/* Header */}
      <div className="glass-panel hud-frame rounded-sm p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Cpu className="h-5 w-5 text-f1-silver" />
          <h2 className="font-black text-f1-white hud-text tracking-widest">SIMULATION MODE</h2>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={regeneratePredictions}
          disabled={isGeneratingPredictions}
          className="gap-2 rounded-sm border-border"
        >
          <RefreshCw className={cn('h-4 w-4', isGeneratingPredictions && 'animate-spin')} />
          {isGeneratingPredictions ? 'ANALYZING...' : 'REFRESH AI'}
        </Button>
      </div>

      {/* Replay Controls */}
      <ReplayControls
        isPlaying={isPlaying}
        onPlayPause={handlePlayPause}
        onReset={handleReset}
        currentLap={currentLap}
        maxLap={maxLap}
        onLapChange={handleLapChange}
        playbackSpeed={playbackSpeed}
        onSpeedChange={setPlaybackSpeed}
      />

      {/* Telemetry Replay */}
      <TelemetryReplay data={currentLapData} currentIndex={currentDataIndex} />

      {/* AI Predictions Section */}
      <div className="glass-panel hud-frame rounded-sm p-4">
        <div className="flex items-center gap-3 mb-4">
          <Brain className="h-4 w-4 text-f1-purple" />
          <h3 className="text-xs font-black text-f1-white hud-text tracking-widest">AI RACE PREDICTIONS</h3>
          {isGeneratingPredictions && (
            <span className="text-[10px] text-f1-cyan animate-pulse hud-text">PROCESSING...</span>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Win Probability Chart */}
          <WinProbabilityChart predictions={predictions} />

          {/* Top Predictions */}
          <div className="space-y-3">
            {predictions.slice(0, 3).map((prediction) => (
              <PredictionCard key={prediction.driverId} prediction={prediction} />
            ))}
          </div>
        </div>
      </div>

      {/* All Driver Predictions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {predictions.slice(3).map((prediction) => (
          <PredictionCard key={prediction.driverId} prediction={prediction} />
        ))}
      </div>
    </div>
  )
}
