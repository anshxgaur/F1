'use client'

import { useState } from 'react'
import { ChevronUp, ChevronDown, Minus, Trophy } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Driver, TyreCompound } from '@/lib/f1-data'
import { getTyreColor } from '@/lib/f1-data'

interface DriverLeaderboardProps {
  drivers: Driver[]
  onDriverSelect: (driver: Driver) => void
  selectedDriverId?: string
  simplified?: boolean
  className?: string
}

function TyreIndicator({ compound, age }: { compound: TyreCompound; age: number }) {
  const color = getTyreColor(compound)
  return (
    <div className="flex items-center gap-1.5">
      <div 
        className="w-5 h-5 rounded-full border-2 flex items-center justify-center"
        style={{ borderColor: color, boxShadow: `0 0 8px ${color}40` }}
      >
        <span className="text-[9px] font-black" style={{ color }}>
          {compound.charAt(0).toUpperCase()}
        </span>
      </div>
      <span className="text-xs text-f1-silver/60 hud-number">{age}</span>
    </div>
  )
}

function DeltaIndicator({ delta }: { delta: number }) {
  if (delta === 0) {
    return <Minus className="h-3 w-3 text-f1-silver/40" />
  }
  if (delta < 0) {
    return (
      <div className="flex items-center gap-0.5 text-f1-green">
        <ChevronUp className="h-4 w-4" />
        <span className="text-xs font-bold hud-number">{Math.abs(delta).toFixed(3)}</span>
      </div>
    )
  }
  return (
    <div className="flex items-center gap-0.5 text-f1-red">
      <ChevronDown className="h-4 w-4" />
      <span className="text-xs font-bold hud-number">{delta.toFixed(3)}</span>
    </div>
  )
}

function PositionBadge({ position }: { position: number }) {
  const getBadgeStyle = (pos: number) => {
    if (pos === 1) return 'bg-f1-yellow text-background glow-yellow'
    if (pos === 2) return 'bg-f1-silver text-background'
    if (pos === 3) return 'bg-f1-orange text-background'
    return 'bg-muted text-f1-silver/70'
  }
  
  return (
    <div className={cn(
      'w-8 h-8 rounded-sm flex items-center justify-center font-black text-sm',
      getBadgeStyle(position)
    )}>
      {position}
    </div>
  )
}

export function DriverLeaderboard({ 
  drivers, 
  onDriverSelect, 
  selectedDriverId,
  simplified = false,
  className 
}: DriverLeaderboardProps) {
  const [hoveredDriver, setHoveredDriver] = useState<string | null>(null)

  return (
    <div className={cn('glass-panel hud-frame rounded-lg overflow-hidden', className)}>
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Trophy className="h-4 w-4 text-f1-yellow" />
          <h2 className="text-xs font-black text-f1-white hud-text tracking-widest">LIVE STANDINGS</h2>
        </div>
        <span className="text-[10px] text-f1-silver/50 hud-text">REAL-TIME</span>
      </div>
      
      {/* Column Headers */}
      <div className="px-4 py-2 bg-muted/30 border-b border-border">
        <div className="grid grid-cols-12 gap-2 text-[9px] text-f1-silver/50 hud-text">
          <div className="col-span-1">POS</div>
          <div className="col-span-4">DRIVER</div>
          {!simplified && <div className="col-span-2 text-right">GAP</div>}
          <div className={cn(simplified ? 'col-span-4' : 'col-span-2', 'text-right')}>INT</div>
          {!simplified && <div className="col-span-2 text-center">TYRE</div>}
          <div className="col-span-2 text-center">DELTA</div>
        </div>
      </div>
      
      {/* Driver List */}
      <div className="overflow-auto max-h-[calc(100vh-340px)]">
        {drivers.map((driver, index) => (
          <div
            key={driver.id}
            onClick={() => onDriverSelect(driver)}
            onMouseEnter={() => setHoveredDriver(driver.id)}
            onMouseLeave={() => setHoveredDriver(null)}
            className={cn(
              'px-4 py-3 cursor-pointer transition-all duration-200 border-b border-border/30',
              'grid grid-cols-12 gap-2 items-center',
              selectedDriverId === driver.id && 'bg-f1-red/10 border-l-2 border-l-f1-red',
              hoveredDriver === driver.id && selectedDriverId !== driver.id && 'bg-glass-white'
            )}
          >
            {/* Position */}
            <div className="col-span-1">
              <PositionBadge position={driver.position} />
            </div>
            
            {/* Driver Info */}
            <div className="col-span-4 flex items-center gap-3">
              <div 
                className="w-1 h-10 rounded-full"
                style={{ backgroundColor: driver.teamColor, boxShadow: `0 0 10px ${driver.teamColor}60` }}
              />
              <div className="flex flex-col">
                <span className="font-black text-f1-white text-sm">{driver.code}</span>
                <span className="text-[10px] text-f1-silver/50 truncate">{driver.team}</span>
              </div>
            </div>
            
            {/* Gap to Leader */}
            {!simplified && (
              <div className="col-span-2 text-right">
                <span className={cn(
                  'text-sm hud-number',
                  driver.gap === 'LEADER' ? 'text-f1-cyan font-black' : 'text-f1-silver/70'
                )}>
                  {driver.gap === 'LEADER' ? 'LEADER' : driver.gap}
                </span>
              </div>
            )}
            
            {/* Interval */}
            <div className={cn(simplified ? 'col-span-4' : 'col-span-2', 'text-right')}>
              <span className="text-sm text-f1-white hud-number font-bold">{driver.interval}</span>
            </div>
            
            {/* Tyre */}
            {!simplified && (
              <div className="col-span-2 flex justify-center">
                <TyreIndicator compound={driver.tyre} age={driver.tyreAge} />
              </div>
            )}
            
            {/* Delta */}
            <div className="col-span-2 flex justify-center">
              <DeltaIndicator delta={driver.delta} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
