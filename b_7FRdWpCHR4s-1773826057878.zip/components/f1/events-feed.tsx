'use client'

import { useEffect, useRef } from 'react'
import { Flag, Zap, AlertTriangle, ArrowRightLeft, PenTool, Swords, Radio } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { RaceEvent } from '@/lib/f1-data'

interface EventsFeedProps {
  events: RaceEvent[]
  className?: string
}

function getEventIcon(type: RaceEvent['type']) {
  const icons = {
    pit: PenTool,
    fastest: Zap,
    flag: Flag,
    overtake: ArrowRightLeft,
    incident: AlertTriangle,
    drs: Zap,
    battle: Swords,
  }
  return icons[type] || Flag
}

function getEventColors(type: RaceEvent['type']) {
  const colors = {
    pit: 'border-l-f1-yellow bg-f1-yellow/5',
    fastest: 'border-l-f1-purple bg-f1-purple/5',
    flag: 'border-l-f1-green bg-f1-green/5',
    overtake: 'border-l-f1-green bg-f1-green/5',
    incident: 'border-l-f1-yellow bg-f1-yellow/5',
    drs: 'border-l-f1-cyan bg-f1-cyan/5',
    battle: 'border-l-f1-orange bg-f1-orange/5',
  }
  return colors[type] || 'border-l-border bg-muted/30'
}

function getIconColor(type: RaceEvent['type']) {
  const colors = {
    pit: 'text-f1-yellow',
    fastest: 'text-f1-purple',
    flag: 'text-f1-green',
    overtake: 'text-f1-green',
    incident: 'text-f1-yellow',
    drs: 'text-f1-cyan',
    battle: 'text-f1-orange',
  }
  return colors[type] || 'text-f1-silver'
}

export function EventsFeed({ events, className }: EventsFeedProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0
    }
  }, [events])

  return (
    <div className={cn('glass-panel hud-frame rounded-lg overflow-hidden', className)}>
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Radio className="h-4 w-4 text-f1-red animate-pulse" />
          <h2 className="text-xs font-black text-f1-white hud-text tracking-widest">RACE FEED</h2>
        </div>
        <span className="text-[9px] text-f1-red font-bold hud-text animate-pulse">LIVE</span>
      </div>
      
      {/* Events List */}
      <div ref={scrollRef} className="p-3 space-y-2 max-h-[350px] overflow-y-auto">
        {events.map((event, index) => {
          const Icon = getEventIcon(event.type)
          const colorClass = getEventColors(event.type)
          const iconColor = getIconColor(event.type)

          return (
            <div
              key={event.id}
              className={cn(
                'flex items-start gap-3 p-3 rounded-sm border-l-2 transition-all',
                colorClass,
                index === 0 && 'animate-data-pulse'
              )}
            >
              <div className={cn('p-1.5 rounded-sm bg-background/50', iconColor)}>
                <Icon className="h-3.5 w-3.5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm leading-tight text-f1-white">{event.message}</p>
                <p className="text-[10px] text-f1-silver/50 font-mono mt-1">{event.time}</p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
