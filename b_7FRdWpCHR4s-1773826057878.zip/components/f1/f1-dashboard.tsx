'use client'

import { useState, useEffect } from 'react'
import { RaceHeader } from './race-header'
import { DriverLeaderboard } from './driver-leaderboard'
import { TelemetryPanel } from './telemetry-panel'
import { TrackMap } from './track-map'
import { EventsFeed } from './events-feed'
import { ModeSelector, type DashboardMode } from './mode-selector'
import { RaceEngineerMode } from './race-engineer-mode'
import { FanMode } from './fan-mode'
import { SimulationMode } from './simulation-mode'
import { 
  drivers as initialDrivers, 
  sessionData, 
  raceEvents, 
  battles,
  aiPredictions,
  historicalLaps,
  type Driver 
} from '@/lib/f1-data'

export function F1Dashboard() {
  const [mode, setMode] = useState<DashboardMode>('dashboard')
  const [drivers, setDrivers] = useState(initialDrivers)
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null)
  const [events, setEvents] = useState(raceEvents)

  // Simulate live data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setDrivers(prev => prev.map(driver => ({
        ...driver,
        speed: Math.max(100, Math.min(350, driver.speed + (Math.random() - 0.5) * 20)),
        throttle: Math.max(0, Math.min(100, driver.throttle + (Math.random() - 0.5) * 15)),
        brake: Math.max(0, Math.min(100, driver.brake + (Math.random() - 0.5) * 10)),
        gear: Math.max(1, Math.min(8, driver.gear + (Math.random() > 0.9 ? (Math.random() > 0.5 ? 1 : -1) : 0))),
        rpm: Math.max(8000, Math.min(12000, driver.rpm + (Math.random() - 0.5) * 500)),
        ers: Math.max(0, Math.min(100, driver.ers + (Math.random() - 0.5) * 5)),
        delta: driver.delta + (Math.random() - 0.5) * 0.1,
      })))
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  // Update selected driver when drivers data changes
  useEffect(() => {
    if (selectedDriver) {
      const updated = drivers.find(d => d.id === selectedDriver.id)
      if (updated) {
        setSelectedDriver(updated)
      }
    }
  }, [drivers, selectedDriver])

  const handleDriverSelect = (driver: Driver) => {
    setSelectedDriver(driver)
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 flex flex-col gap-4 grid-overlay">
      {/* Top Bar */}
      <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center justify-between">
        <RaceHeader session={sessionData} className="flex-1 w-full xl:w-auto" />
        <ModeSelector currentMode={mode} onModeChange={setMode} />
      </div>

      {/* Main Content */}
      {mode === 'dashboard' && (
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left Panel - Leaderboard */}
          <div className="lg:col-span-3">
            <DriverLeaderboard 
              drivers={drivers} 
              onDriverSelect={handleDriverSelect}
              selectedDriverId={selectedDriver?.id}
            />
          </div>

          {/* Center Panel - Telemetry */}
          <div className="lg:col-span-6 flex flex-col gap-4">
            <TelemetryPanel driver={selectedDriver} />
            <TrackMap 
              drivers={drivers} 
              selectedDriverId={selectedDriver?.id}
            />
          </div>

          {/* Right Panel - Events */}
          <div className="lg:col-span-3">
            <EventsFeed events={events} />
          </div>
        </div>
      )}

      {mode === 'engineer' && (
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left - Leaderboard & Track */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <DriverLeaderboard 
              drivers={drivers} 
              onDriverSelect={handleDriverSelect}
              selectedDriverId={selectedDriver?.id}
            />
            <TrackMap 
              drivers={drivers} 
              selectedDriverId={selectedDriver?.id}
            />
          </div>

          {/* Center - Telemetry */}
          <div className="lg:col-span-4">
            <TelemetryPanel driver={selectedDriver} />
          </div>

          {/* Right - Engineer AI */}
          <div className="lg:col-span-4">
            <RaceEngineerMode 
              drivers={drivers}
              predictions={aiPredictions}
              onDriverSelect={handleDriverSelect}
            />
          </div>
        </div>
      )}

      {mode === 'fan' && (
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Main Content - Fan Mode */}
          <div className="lg:col-span-8">
            <FanMode 
              drivers={drivers}
              battles={battles}
              events={events}
              onDriverSelect={handleDriverSelect}
              selectedDriverId={selectedDriver?.id}
            />
          </div>

          {/* Right - Track & Events */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <TrackMap 
              drivers={drivers} 
              selectedDriverId={selectedDriver?.id}
            />
            <EventsFeed events={events} className="flex-1" />
          </div>
        </div>
      )}

      {mode === 'simulation' && (
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Main Simulation */}
          <div className="lg:col-span-8">
            <SimulationMode 
              drivers={drivers}
              historicalLaps={historicalLaps}
            />
          </div>

          {/* Right - Standings & Track */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <DriverLeaderboard 
              drivers={drivers} 
              onDriverSelect={handleDriverSelect}
              selectedDriverId={selectedDriver?.id}
              simplified
            />
            <TrackMap 
              drivers={drivers} 
              selectedDriverId={selectedDriver?.id}
            />
          </div>
        </div>
      )}

      {/* Cinematic scanline overlay */}
      <div className="fixed inset-0 pointer-events-none scanline opacity-30" />
    </div>
  )
}
