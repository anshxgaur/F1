'use client'

import { useState, useEffect, useRef } from 'react'
import { Swords, MessageSquare, Flame, Zap, Trophy, ChevronUp, ChevronDown, Volume2, VolumeX, Tv } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Driver, Battle, RaceEvent } from '@/lib/f1-data'
import { DriverLeaderboard } from './driver-leaderboard'

interface FanModeProps {
  drivers: Driver[]
  battles: Battle[]
  events: RaceEvent[]
  onDriverSelect: (driver: Driver) => void
  selectedDriverId?: string
  className?: string
}

interface Commentary {
  id: string
  text: string
  type: 'exciting' | 'normal' | 'critical'
  timestamp: Date
}

const commentaryTemplates = {
  battle: [
    "WHEEL TO WHEEL! {d1} and {d2} are fighting tooth and nail! This is incredible racing!",
    "The gap is just {gap} seconds! {d1} is right in {d2}'s mirrors!",
    "DRS ZONE APPROACHING! {d1} has the chance to make a move on {d2}!",
    "WHAT A BATTLE! These two are putting on a masterclass!",
  ],
  overtake: [
    "OVERTAKE! {driver} makes it stick! Brilliant move!",
    "HE'S THROUGH! {driver} executes perfectly!",
    "WHAT A MOVE! {driver} shows nerves of steel!",
  ],
  fastest: [
    "PURPLE SECTOR! {driver} is absolutely flying!",
    "FASTEST LAP! {driver} sets the benchmark!",
    "Incredible pace from {driver}! The car is alive!",
  ],
  pit: [
    "{driver} dives into the pit lane! Let's see the stop...",
    "Box box box for {driver}! Critical moment!",
  ],
  general: [
    "The tension is palpable here at Monaco!",
    "Every corner, every braking zone - it's all on the line!",
    "This is what Formula 1 is all about, folks!",
    "The crowd is on their feet!",
  ],
}

function BattleCard({ battle, drivers }: { battle: Battle; drivers: Driver[] }) {
  const driver1 = drivers.find(d => d.code === battle.drivers[0])
  const driver2 = drivers.find(d => d.code === battle.drivers[1])

  const battleTypeColors = {
    drs: 'border-f1-cyan bg-f1-cyan/5',
    'wheel-to-wheel': 'border-f1-red bg-f1-red/5',
    defending: 'border-f1-orange bg-f1-orange/5',
  }

  const battleTypeIcons = {
    drs: <Zap className="h-4 w-4 text-f1-cyan" />,
    'wheel-to-wheel': <Flame className="h-4 w-4 text-f1-red" />,
    defending: <Swords className="h-4 w-4 text-f1-orange" />,
  }

  return (
    <div className={cn(
      'rounded-sm border-l-2 p-4 glass-panel-light',
      battleTypeColors[battle.type]
    )}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {battleTypeIcons[battle.type]}
          <span className="text-[10px] font-black hud-text uppercase tracking-widest text-f1-white">
            {battle.type.replace('-', ' ')}
          </span>
        </div>
        <span className="text-[10px] font-mono text-f1-silver/50">
          {Math.floor(battle.duration / 60)}:{(battle.duration % 60).toString().padStart(2, '0')}
        </span>
      </div>

      <div className="flex items-center justify-between">
        {/* Driver 1 */}
        <div className="flex items-center gap-3">
          <div 
            className="w-1.5 h-10 rounded-full"
            style={{ backgroundColor: driver1?.teamColor, boxShadow: `0 0 10px ${driver1?.teamColor}60` }}
          />
          <div>
            <span className="font-black text-xl text-f1-white">{battle.drivers[0]}</span>
            <span className="text-[10px] text-f1-silver/50 block">{driver1?.team}</span>
          </div>
        </div>

        {/* Gap */}
        <div className="flex flex-col items-center px-6">
          <div className="flex items-center gap-2">
            <ChevronUp className="h-5 w-5 text-f1-green animate-bounce" />
            <span className="text-3xl font-black text-f1-white hud-number">
              {battle.gap.toFixed(1)}<span className="text-lg text-f1-silver/50">s</span>
            </span>
            <ChevronDown className="h-5 w-5 text-f1-red animate-bounce" />
          </div>
          <span className="text-[9px] text-f1-silver/40 hud-text">GAP</span>
        </div>

        {/* Driver 2 */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="font-black text-xl text-f1-white">{battle.drivers[1]}</span>
            <span className="text-[10px] text-f1-silver/50 block">{driver2?.team}</span>
          </div>
          <div 
            className="w-1.5 h-10 rounded-full"
            style={{ backgroundColor: driver2?.teamColor, boxShadow: `0 0 10px ${driver2?.teamColor}60` }}
          />
        </div>
      </div>
    </div>
  )
}

function CommentaryPanel({ commentaries }: { commentaries: Commentary[] }) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [commentaries])

  const typeStyles = {
    exciting: 'text-f1-yellow font-bold animate-data-pulse',
    normal: 'text-f1-silver',
    critical: 'text-f1-red font-bold',
  }

  return (
    <div className="glass-panel hud-frame rounded-lg overflow-hidden h-full flex flex-col">
      <div className="p-4 border-b border-border flex items-center gap-3">
        <MessageSquare className="h-4 w-4 text-f1-cyan" />
        <h3 className="text-xs font-black text-f1-white hud-text tracking-widest">LIVE COMMENTARY</h3>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {commentaries.map((commentary) => (
          <div key={commentary.id} className="flex gap-3">
            <span className="text-[10px] text-f1-silver/40 font-mono whitespace-nowrap pt-0.5">
              {commentary.timestamp.toLocaleTimeString()}
            </span>
            <p className={cn('text-sm leading-relaxed', typeStyles[commentary.type])}>
              {commentary.text}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

function QuickStats({ drivers }: { drivers: Driver[] }) {
  const leader = drivers[0]
  const fastestLap = [...drivers].sort((a, b) => a.bestLap.localeCompare(b.bestLap))[0]

  return (
    <div className="grid grid-cols-2 gap-3">
      <div className="glass-panel hud-frame rounded-sm p-4">
        <div className="flex items-center gap-2 mb-3">
          <Trophy className="h-4 w-4 text-f1-yellow" />
          <span className="text-[9px] text-f1-silver/50 hud-text tracking-widest">RACE LEADER</span>
        </div>
        <div className="flex items-center gap-3">
          <div 
            className="w-1.5 h-12 rounded-full"
            style={{ backgroundColor: leader.teamColor, boxShadow: `0 0 12px ${leader.teamColor}60` }}
          />
          <div>
            <span className="text-3xl font-black text-f1-white">{leader.code}</span>
            <span className="text-[10px] text-f1-silver/50 block">{leader.team}</span>
          </div>
        </div>
      </div>

      <div className="glass-panel hud-frame rounded-sm p-4">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="h-4 w-4 text-f1-purple" />
          <span className="text-[9px] text-f1-silver/50 hud-text tracking-widest">FASTEST LAP</span>
        </div>
        <div className="flex items-center gap-3">
          <div 
            className="w-1.5 h-12 rounded-full"
            style={{ backgroundColor: fastestLap.teamColor, boxShadow: `0 0 12px ${fastestLap.teamColor}60` }}
          />
          <div>
            <span className="text-2xl font-black text-f1-purple hud-number">{fastestLap.bestLap}</span>
            <span className="text-[10px] text-f1-silver/50 block">{fastestLap.code}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export function FanMode({ drivers, battles, events, onDriverSelect, selectedDriverId, className }: FanModeProps) {
  const [commentaries, setCommentaries] = useState<Commentary[]>([])
  const [isMuted, setIsMuted] = useState(true)
  const commentaryIdRef = useRef(0)
  const initializedRef = useRef(false)

  // Generate live commentary
  useEffect(() => {
    const generateCommentary = () => {
      const rand = Math.random()
      let text: string
      let type: Commentary['type'] = 'normal'

      if (rand < 0.3 && battles.length > 0) {
        // Battle commentary
        const battle = battles[Math.floor(Math.random() * battles.length)]
        const templates = commentaryTemplates.battle
        text = templates[Math.floor(Math.random() * templates.length)]
          .replace('{d1}', battle.drivers[0])
          .replace('{d2}', battle.drivers[1])
          .replace('{gap}', battle.gap.toFixed(1))
        type = 'exciting'
      } else if (rand < 0.5) {
        // Fastest lap commentary
        const fastest = [...drivers].sort((a, b) => a.bestLap.localeCompare(b.bestLap))[0]
        const templates = commentaryTemplates.fastest
        text = templates[Math.floor(Math.random() * templates.length)]
          .replace('{driver}', fastest.name)
        type = 'exciting'
      } else {
        // General commentary
        const templates = commentaryTemplates.general
        text = templates[Math.floor(Math.random() * templates.length)]
        type = 'normal'
      }

      commentaryIdRef.current += 1
      const newCommentary: Commentary = {
        id: `commentary-${commentaryIdRef.current}-${Date.now()}`,
        text,
        type,
        timestamp: new Date(),
      }

      setCommentaries(prev => [...prev.slice(-20), newCommentary])

      // Speak if not muted
      if (!isMuted && 'speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text)
        utterance.rate = 1.2
        utterance.pitch = 1.1
        window.speechSynthesis.speak(utterance)
      }
    }

    // Initial commentary - only run once
    if (!initializedRef.current) {
      initializedRef.current = true
      generateCommentary()
    }

    const interval = setInterval(generateCommentary, 8000)
    return () => clearInterval(interval)
  }, [battles, drivers, isMuted])

  // Convert events to commentary
  useEffect(() => {
    if (events.length > 0) {
      const latestEvent = events[0]
      const eventCommentary: Commentary = {
        id: `event-${latestEvent.id}`,
        text: latestEvent.message,
        type: latestEvent.type === 'overtake' || latestEvent.type === 'fastest' ? 'exciting' : 'normal',
        timestamp: new Date(),
      }
      setCommentaries(prev => {
        if (prev.find(c => c.id === eventCommentary.id)) return prev
        return [...prev.slice(-20), eventCommentary]
      })
    }
  }, [events])

  return (
    <div className={cn('flex flex-col gap-4 h-full', className)}>
      {/* Header */}
      <div className="glass-panel hud-frame rounded-sm p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Tv className="h-5 w-5 text-f1-cyan" />
          <h2 className="font-black text-f1-white hud-text tracking-widest">FAN MODE</h2>
          <span className="text-[9px] px-2 py-1 rounded-sm bg-f1-red text-white font-black animate-pulse">
            LIVE
          </span>
        </div>
        <button
          onClick={() => setIsMuted(!isMuted)}
          className="p-2.5 rounded-sm glass-panel-light hover:bg-glass-white transition-colors"
        >
          {isMuted ? (
            <VolumeX className="h-4 w-4 text-f1-silver/50" />
          ) : (
            <Volume2 className="h-4 w-4 text-f1-cyan" />
          )}
        </button>
      </div>

      {/* Quick Stats */}
      <QuickStats drivers={drivers} />

      {/* Battles Section */}
      {battles.length > 0 && (
        <div className="glass-panel hud-frame rounded-sm p-4">
          <div className="flex items-center gap-3 mb-4">
            <Swords className="h-4 w-4 text-f1-orange" />
            <h3 className="text-xs font-black text-f1-white hud-text tracking-widest">LIVE BATTLES</h3>
            <span className="text-[9px] px-2 py-1 rounded-sm bg-f1-orange/20 text-f1-orange font-bold">
              {battles.length} ACTIVE
            </span>
          </div>
          <div className="space-y-3">
            {battles.map((battle) => (
              <BattleCard key={battle.id} battle={battle} drivers={drivers} />
            ))}
          </div>
        </div>
      )}

      {/* Simplified Leaderboard */}
      <DriverLeaderboard
        drivers={drivers}
        onDriverSelect={onDriverSelect}
        selectedDriverId={selectedDriverId}
        simplified
        className="flex-shrink-0"
      />

      {/* Commentary Panel */}
      <div className="flex-1 min-h-[200px]">
        <CommentaryPanel commentaries={commentaries} />
      </div>
    </div>
  )
}
