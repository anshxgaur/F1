'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import type { Driver } from '@/lib/f1-data'
import { MapPin, Radio } from 'lucide-react'

interface TrackMapProps {
  drivers: Driver[]
  selectedDriverId?: string
  className?: string
}

// Monaco circuit coordinates (simplified)
const trackPath = `
  M 50,10 
  C 80,10 95,25 95,50 
  C 95,65 85,75 75,80 
  L 70,82 
  C 60,85 50,90 40,90 
  C 20,90 10,75 10,55 
  C 10,35 20,20 35,15 
  L 50,10
`

// Generate positions around the track
function getDriverPosition(index: number, total: number): { x: number; y: number } {
  const angle = (index / total) * Math.PI * 2 - Math.PI / 2
  const radiusX = 35
  const radiusY = 35
  return {
    x: 50 + Math.cos(angle) * radiusX + (Math.random() - 0.5) * 5,
    y: 50 + Math.sin(angle) * radiusY + (Math.random() - 0.5) * 5,
  }
}

export function TrackMap({ drivers, selectedDriverId, className }: TrackMapProps) {
  const [positions, setPositions] = useState<Map<string, { x: number; y: number }>>(new Map())

  useEffect(() => {
    const newPositions = new Map<string, { x: number; y: number }>()
    drivers.forEach((driver, index) => {
      newPositions.set(driver.id, getDriverPosition(index, drivers.length))
    })
    setPositions(newPositions)

    // Animate positions
    const interval = setInterval(() => {
      setPositions(prev => {
        const updated = new Map(prev)
        drivers.forEach((driver) => {
          const current = updated.get(driver.id)
          if (current) {
            updated.set(driver.id, {
              x: current.x + (Math.random() - 0.5) * 2,
              y: current.y + (Math.random() - 0.5) * 2,
            })
          }
        })
        return updated
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [drivers])

  return (
    <div className={cn('glass-panel hud-frame rounded-lg p-4', className)}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4 text-f1-red" />
          <h3 className="text-[10px] text-f1-white hud-text font-black tracking-widest">TRACK MAP</h3>
        </div>
        <div className="flex items-center gap-2 text-f1-cyan">
          <Radio className="h-3 w-3 animate-pulse" />
          <span className="text-[9px] hud-text">LIVE GPS</span>
        </div>
      </div>
      
      <div className="relative aspect-square max-w-[280px] mx-auto">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {/* Track glow effect */}
          <defs>
            <filter id="trackGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="1" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          
          {/* Track outline - outer edge */}
          <path
            d={trackPath}
            fill="none"
            stroke="oklch(0.3 0.01 250)"
            strokeWidth="10"
            strokeLinecap="round"
          />
          
          {/* Track surface */}
          <path
            d={trackPath}
            fill="none"
            stroke="oklch(0.15 0.005 250)"
            strokeWidth="8"
            strokeLinecap="round"
          />
          
          {/* Track center line - racing line */}
          <path
            d={trackPath}
            fill="none"
            stroke="oklch(0.25 0.01 250)"
            strokeWidth="0.5"
            strokeLinecap="round"
            strokeDasharray="2 2"
          />

          {/* Sector markers */}
          <g filter="url(#trackGlow)">
            <circle cx="72" cy="25" r="2.5" fill="oklch(0.58 0.24 25)" />
            <circle cx="25" cy="75" r="2.5" fill="oklch(0.58 0.24 25)" />
            <circle cx="50" cy="10" r="2.5" fill="oklch(0.58 0.24 25)" />
          </g>
          
          {/* Sector labels */}
          <text x="76" y="22" fontSize="3" fill="oklch(0.58 0.24 25)" className="font-mono">S1</text>
          <text x="28" y="72" fontSize="3" fill="oklch(0.58 0.24 25)" className="font-mono">S2</text>
          <text x="54" y="8" fontSize="3" fill="oklch(0.58 0.24 25)" className="font-mono">S3</text>

          {/* DRS Zones */}
          <path
            d="M 50,10 C 80,10 95,25 95,40"
            fill="none"
            stroke="oklch(0.78 0.14 195 / 0.4)"
            strokeWidth="3"
            strokeDasharray="3 1.5"
            filter="url(#trackGlow)"
          />
          
          <text x="85" y="30" fontSize="2.5" fill="oklch(0.78 0.14 195)" className="font-mono">DRS</text>

          {/* Driver positions */}
          {drivers.map((driver) => {
            const pos = positions.get(driver.id)
            if (!pos) return null
            const isSelected = selectedDriverId === driver.id

            return (
              <g key={driver.id}>
                {/* Glow effect for selected */}
                {isSelected && (
                  <>
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r="8"
                      fill="none"
                      stroke={driver.teamColor}
                      strokeWidth="0.5"
                      opacity="0.3"
                      className="animate-ping"
                    />
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r="5"
                      fill="none"
                      stroke={driver.teamColor}
                      strokeWidth="0.5"
                      opacity="0.5"
                    />
                  </>
                )}
                {/* Driver dot */}
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r={isSelected ? "4" : "2.5"}
                  fill={driver.teamColor}
                  className="transition-all duration-300"
                  style={{ filter: `drop-shadow(0 0 ${isSelected ? '6px' : '3px'} ${driver.teamColor})` }}
                />
                {/* Driver code */}
                {isSelected && (
                  <text
                    x={pos.x}
                    y={pos.y - 7}
                    fontSize="4"
                    fill="white"
                    textAnchor="middle"
                    className="font-mono font-bold"
                    style={{ filter: 'drop-shadow(0 0 2px black)' }}
                  >
                    {driver.code}
                  </text>
                )}
              </g>
            )
          })}

          {/* Start/Finish line */}
          <line
            x1="45"
            y1="8"
            x2="55"
            y2="8"
            stroke="white"
            strokeWidth="1.5"
          />
          <rect x="44" y="6" width="12" height="4" fill="white" fillOpacity="0.1" />
        </svg>

        {/* Legend */}
        <div className="absolute bottom-0 left-0 right-0 flex justify-center gap-6 text-[9px]">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 bg-f1-red rounded-full" style={{ boxShadow: '0 0 6px oklch(0.58 0.24 25)' }} />
            <span className="text-f1-silver/50">Sectors</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-0.5 bg-f1-cyan opacity-60" />
            <span className="text-f1-silver/50">DRS Zone</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-1 bg-white" />
            <span className="text-f1-silver/50">Start/Finish</span>
          </div>
        </div>
      </div>
    </div>
  )
}
