'use client'

import { useMemo } from 'react'
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Area, AreaChart, ComposedChart, Bar } from 'recharts'
import { cn } from '@/lib/utils'
import type { Driver } from '@/lib/f1-data'
import { getTyreColor } from '@/lib/f1-data'
import { Activity, Gauge, Zap, Fuel, Timer } from 'lucide-react'

interface TelemetryPanelProps {
  driver: Driver | null
  className?: string
}

// Generate mock telemetry data for visualization
function generateTelemetryData() {
  return Array.from({ length: 50 }, (_, i) => ({
    distance: i * 66,
    speed: 180 + Math.sin(i * 0.2) * 80 + Math.random() * 15,
    throttle: Math.max(0, Math.min(100, 50 + Math.sin(i * 0.2) * 48 + Math.random() * 5)),
    brake: Math.max(0, Math.min(100, Math.cos(i * 0.2) * 45 + Math.random() * 10)),
  }))
}

function SpeedGauge({ speed, maxSpeed = 350 }: { speed: number; maxSpeed?: number }) {
  const percentage = (speed / maxSpeed) * 100
  const circumference = 2 * Math.PI * 42
  const offset = circumference - (percentage / 100) * circumference * 0.75

  return (
    <div className="relative w-36 h-36">
      <svg className="w-full h-full -rotate-135" viewBox="0 0 100 100">
        {/* Background arc */}
        <circle
          cx="50"
          cy="50"
          r="42"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
          strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
          className="text-muted"
        />
        {/* Progress arc */}
        <circle
          cx="50"
          cy="50"
          r="42"
          fill="none"
          stroke="url(#speedGradientCinematic)"
          strokeWidth="5"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-all duration-300"
          style={{ filter: 'drop-shadow(0 0 8px oklch(0.78 0.14 195 / 0.5))' }}
        />
        <defs>
          <linearGradient id="speedGradientCinematic" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="oklch(0.78 0.14 195)" />
            <stop offset="60%" stopColor="oklch(0.98 0 0)" />
            <stop offset="100%" stopColor="oklch(0.58 0.24 25)" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-4xl font-black text-f1-white hud-number text-glow-white">{speed}</span>
        <span className="text-[10px] text-f1-silver/50 hud-text mt-1">KM/H</span>
      </div>
    </div>
  )
}

function GearDisplay({ gear }: { gear: number }) {
  return (
    <div className="flex flex-col items-center">
      <span className="text-[9px] text-f1-silver/50 hud-text mb-2">GEAR</span>
      <div className="w-16 h-16 rounded-sm glass-panel-light flex items-center justify-center border border-f1-silver/20">
        <span className="text-5xl font-black text-f1-white hud-number">{gear}</span>
      </div>
    </div>
  )
}

function MetricBar({ label, value, color, icon: Icon }: { label: string; value: number; color: string; icon: React.ComponentType<{ className?: string }> }) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex justify-between items-center text-xs">
        <div className="flex items-center gap-2">
          <Icon className="h-3 w-3" style={{ color }} />
          <span className="text-f1-silver/50 hud-text">{label}</span>
        </div>
        <span className="font-bold hud-number" style={{ color }}>{value}%</span>
      </div>
      <div className="h-2 bg-muted rounded-sm overflow-hidden">
        <div 
          className="h-full transition-all duration-300 rounded-sm"
          style={{ 
            width: `${value}%`, 
            backgroundColor: color,
            boxShadow: `0 0 10px ${color}60`
          }}
        />
      </div>
    </div>
  )
}

function TyreWearDisplay({ wear, position }: { wear: number; position: string }) {
  const getWearColor = (w: number) => {
    if (w < 30) return 'text-f1-green'
    if (w < 50) return 'text-f1-yellow'
    if (w < 70) return 'text-f1-orange'
    return 'text-f1-red'
  }

  return (
    <div className="flex flex-col items-center glass-panel-light rounded-sm p-2">
      <span className="text-[9px] text-f1-silver/50 hud-text">{position}</span>
      <span className={cn('text-lg font-black hud-number', getWearColor(wear))}>{wear}%</span>
    </div>
  )
}

function SectorTime({ sector, time, status }: { sector: number; time: number; status: 'pb' | 'sb' | 'normal' }) {
  const statusStyles = {
    pb: 'bg-f1-green text-background',
    sb: 'bg-f1-purple text-white',
    normal: 'bg-muted text-f1-silver',
  }

  return (
    <div className={cn('px-4 py-2 rounded-sm text-center', statusStyles[status])}>
      <span className="text-[9px] block mb-0.5 opacity-70">S{sector}</span>
      <span className="font-black text-sm hud-number">{time.toFixed(3)}</span>
    </div>
  )
}

export function TelemetryPanel({ driver, className }: TelemetryPanelProps) {
  const telemetryData = useMemo(() => generateTelemetryData(), [])

  if (!driver) {
    return (
      <div className={cn('glass-panel hud-frame rounded-lg p-8 flex flex-col items-center justify-center min-h-[400px]', className)}>
        <Activity className="h-12 w-12 text-f1-silver/20 mb-4" />
        <p className="text-f1-silver/40 hud-text text-sm">SELECT A DRIVER TO VIEW TELEMETRY</p>
      </div>
    )
  }

  return (
    <div className={cn('glass-panel hud-frame rounded-lg overflow-hidden', className)}>
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div 
            className="w-1.5 h-12 rounded-full"
            style={{ backgroundColor: driver.teamColor, boxShadow: `0 0 15px ${driver.teamColor}80` }}
          />
          <div>
            <h2 className="text-2xl font-black text-f1-white cinematic-title">{driver.name}</h2>
            <p className="text-xs text-f1-silver/50">{driver.team}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-4xl font-black hud-number" style={{ color: driver.teamColor, textShadow: `0 0 20px ${driver.teamColor}60` }}>
            #{driver.number}
          </p>
        </div>
      </div>

      {/* Main Telemetry Grid */}
      <div className="p-5 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Speed & Gear */}
        <div className="flex items-center justify-around">
          <SpeedGauge speed={driver.speed} />
          <GearDisplay gear={driver.gear} />
        </div>

        {/* RPM & ERS */}
        <div className="flex flex-col gap-4">
          <div className="flex justify-between items-center text-xs">
            <div className="flex items-center gap-2">
              <Gauge className="h-3 w-3 text-f1-red" />
              <span className="text-f1-silver/50 hud-text">RPM</span>
            </div>
            <span className="font-black text-f1-white hud-number text-lg">{driver.rpm.toLocaleString()}</span>
          </div>
          <div className="h-4 bg-muted rounded-sm overflow-hidden flex gap-0.5">
            {Array.from({ length: 12 }).map((_, i) => (
              <div 
                key={i}
                className={cn(
                  'flex-1 transition-all rounded-sm',
                  i < Math.floor(driver.rpm / 1000) 
                    ? i < 8 ? 'bg-f1-green' : i < 10 ? 'bg-f1-yellow' : 'bg-f1-red'
                    : 'bg-transparent'
                )}
                style={i < Math.floor(driver.rpm / 1000) ? { 
                  boxShadow: i >= 10 ? '0 0 8px oklch(0.58 0.24 25 / 0.6)' : undefined 
                } : undefined}
              />
            ))}
          </div>
          <MetricBar label="ERS" value={driver.ers} color="oklch(0.78 0.14 195)" icon={Zap} />
          <MetricBar label="FUEL" value={driver.fuel} color="oklch(0.88 0.16 90)" icon={Fuel} />
        </div>

        {/* Throttle/Brake */}
        <div className="flex flex-col gap-4">
          <MetricBar label="THROTTLE" value={driver.throttle} color="oklch(0.7 0.18 145)" icon={Activity} />
          <MetricBar label="BRAKE" value={driver.brake} color="oklch(0.58 0.24 25)" icon={Activity} />
          <div className="grid grid-cols-2 gap-3 mt-2">
            <div className="glass-panel-light rounded-sm p-3 text-center">
              <span className="text-[9px] text-f1-silver/50 hud-text block mb-1">LAST LAP</span>
              <span className="text-lg font-black text-f1-white hud-number">{driver.lastLap}</span>
            </div>
            <div className="glass-panel-light rounded-sm p-3 text-center">
              <span className="text-[9px] text-f1-silver/50 hud-text block mb-1">BEST LAP</span>
              <span className="text-lg font-black text-f1-purple hud-number">{driver.bestLap}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Speed Trace */}
      <div className="px-5 pb-3">
        <p className="text-[9px] text-f1-silver/50 hud-text mb-2">SPEED TRACE</p>
        <div className="h-20 glass-panel-light rounded-sm p-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={telemetryData}>
              <defs>
                <linearGradient id="speedGradCinematic" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.78 0.14 195)" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="oklch(0.78 0.14 195)" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Area 
                type="monotone" 
                dataKey="speed" 
                stroke="oklch(0.78 0.14 195)" 
                strokeWidth={2}
                fill="url(#speedGradCinematic)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Throttle/Brake Trace */}
      <div className="px-5 pb-5">
        <p className="text-[9px] text-f1-silver/50 hud-text mb-2">THROTTLE / BRAKE</p>
        <div className="h-16 glass-panel-light rounded-sm p-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={telemetryData}>
              <Area 
                type="monotone" 
                dataKey="throttle" 
                stroke="oklch(0.7 0.18 145)" 
                strokeWidth={1.5}
                fill="oklch(0.7 0.18 145 / 0.2)" 
              />
              <Area 
                type="monotone" 
                dataKey="brake" 
                stroke="oklch(0.58 0.24 25)" 
                strokeWidth={1.5}
                fill="oklch(0.58 0.24 25 / 0.2)" 
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Section - Tyres & Sectors */}
      <div className="px-5 pb-5 grid grid-cols-2 gap-4">
        {/* Tyre Wear */}
        <div className="glass-panel rounded-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-[9px] text-f1-silver/50 hud-text">TYRE WEAR</p>
            <div 
              className="w-6 h-6 rounded-full border-2 flex items-center justify-center"
              style={{ borderColor: getTyreColor(driver.tyre), boxShadow: `0 0 10px ${getTyreColor(driver.tyre)}40` }}
            >
              <span className="text-[8px] font-black" style={{ color: getTyreColor(driver.tyre) }}>
                {driver.tyre.charAt(0).toUpperCase()}
              </span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <TyreWearDisplay wear={driver.tyreWear.fl} position="FL" />
            <TyreWearDisplay wear={driver.tyreWear.fr} position="FR" />
            <TyreWearDisplay wear={driver.tyreWear.rl} position="RL" />
            <TyreWearDisplay wear={driver.tyreWear.rr} position="RR" />
          </div>
        </div>

        {/* Sector Times */}
        <div className="glass-panel rounded-sm p-4">
          <p className="text-[9px] text-f1-silver/50 hud-text mb-3">SECTOR TIMES</p>
          <div className="flex flex-col gap-2">
            <SectorTime sector={1} time={driver.sectorTimes.s1} status={driver.sectorStatus.s1} />
            <SectorTime sector={2} time={driver.sectorTimes.s2} status={driver.sectorStatus.s2} />
            <SectorTime sector={3} time={driver.sectorTimes.s3} status={driver.sectorStatus.s3} />
          </div>
        </div>
      </div>
    </div>
  )
}
