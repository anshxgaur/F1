'use client'

import { Flag, Cloud, Thermometer, Wind, Droplets, Timer } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { SessionData, FlagStatus } from '@/lib/f1-data'

interface RaceHeaderProps {
  session: SessionData
  className?: string
}

function getFlagDisplay(flag: FlagStatus) {
  const config: Record<FlagStatus, { color: string; text: string; glow: string }> = {
    green: { color: 'bg-f1-green', text: 'GREEN', glow: 'glow-green' },
    yellow: { color: 'bg-f1-yellow', text: 'YELLOW', glow: 'glow-yellow' },
    red: { color: 'bg-f1-red', text: 'RED', glow: 'glow-red' },
    'safety-car': { color: 'bg-f1-yellow', text: 'SAFETY CAR', glow: 'glow-yellow' },
    vsc: { color: 'bg-f1-yellow', text: 'VSC', glow: 'glow-yellow' },
    checkered: { color: 'bg-foreground', text: 'CHECKERED', glow: '' },
  }
  return config[flag]
}

export function RaceHeader({ session, className }: RaceHeaderProps) {
  const flagDisplay = getFlagDisplay(session.flag)

  return (
    <header className={cn('glass-panel rounded-lg p-4', className)}>
      <div className="flex items-center justify-between gap-4 flex-wrap">
        {/* Session Info */}
        <div className="flex items-center gap-6">
          <div className="flex flex-col">
            <span className="text-xs text-muted-foreground hud-text">SESSION</span>
            <span className="text-lg font-bold text-f1-red hud-text">{session.type}</span>
          </div>
          <div className="h-8 w-px bg-border" />
          <div className="flex flex-col">
            <span className="text-xs text-muted-foreground hud-text">CIRCUIT</span>
            <span className="text-lg font-bold hud-text">{session.track}</span>
          </div>
          <div className="h-8 w-px bg-border hidden sm:block" />
          <div className="flex flex-col hidden sm:flex">
            <span className="text-xs text-muted-foreground hud-text">LAP</span>
            <span className="text-lg font-bold font-mono">
              <span className="text-f1-cyan">{session.currentLap}</span>
              <span className="text-muted-foreground">/{session.totalLaps}</span>
            </span>
          </div>
        </div>

        {/* Flag Status */}
        <div className={cn('flex items-center gap-2 px-4 py-2 rounded-md', flagDisplay.color, flagDisplay.glow)}>
          <Flag className="h-4 w-4 text-background" />
          <span className="font-bold text-background hud-text text-sm">{flagDisplay.text}</span>
        </div>

        {/* Weather */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Thermometer className="h-4 w-4 text-f1-red" />
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">AIR</span>
              <span className="font-mono text-sm">{session.weather.airTemp}°C</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Thermometer className="h-4 w-4 text-f1-orange" />
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">TRACK</span>
              <span className="font-mono text-sm">{session.weather.trackTemp}°C</span>
            </div>
          </div>
          <div className="flex items-center gap-2 hidden md:flex">
            <Wind className="h-4 w-4 text-f1-cyan" />
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">WIND</span>
              <span className="font-mono text-sm">{session.weather.wind} km/h {session.weather.windDirection}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 hidden lg:flex">
            <Droplets className="h-4 w-4 text-f1-blue" />
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">HUMIDITY</span>
              <span className="font-mono text-sm">{session.weather.humidity}%</span>
            </div>
          </div>
        </div>

        {/* Timer */}
        <div className="flex items-center gap-2">
          <Timer className="h-5 w-5 text-muted-foreground" />
          <span className="text-2xl font-mono font-bold text-f1-cyan animate-pulse-glow">
            {session.timeRemaining}
          </span>
        </div>
      </div>
    </header>
  )
}
