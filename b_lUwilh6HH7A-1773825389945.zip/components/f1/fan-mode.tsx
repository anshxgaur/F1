'use client'

import { useState, useEffect, useRef } from 'react'
import { Swords, MessageSquare, Flame, Zap, Trophy, ChevronUp, ChevronDown, Volume2, VolumeX } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Driver, Battle, RaceEvent } from '@/lib/f1-data'
import { DriverLeaderboard } from './driver-leaderboard'

interface FanModeProps {
  drivers: Driver[]
  battles: Battle[]
  events: RaceEvent[]
  onDriverSelect: (driver: Driver) => void
  selectedDriverId?: string
  className?: string
}

interface Commentary {
  id: string
  text: string
  type: 'exciting' | 'normal' | 'critical'
  timestamp: Date
}

const commentaryTemplates = {
  battle: [
    "WHEEL TO WHEEL! {d1} and {d2} are fighting tooth and nail! This is incredible racing!",
    "The gap is just {gap} seconds! {d1} is right in {d2}'s mirrors!",
    "DRS ZONE APPROACHING! {d1} has the chance to make a move on {d2}!",
    "WHAT A BATTLE! These two are putting on a masterclass!",
  ],
  overtake: [
    "OVERTAKE! {driver} makes it stick! Brilliant move!",
    "HE'S THROUGH! {driver} executes perfectly!",
    "WHAT A MOVE! {driver} shows nerves of steel!",
  ],
  fastest: [
    "PURPLE SECTOR! {driver} is absolutely flying!",
    "FASTEST LAP! {driver} sets the benchmark!",
    "Incredible pace from {driver}! The car is alive!",
  ],
  pit: [
    "{driver} dives into the pit lane! Let's see the stop...",
    "Box box box for {driver}! Critical moment!",
  ],
  general: [
    "The tension is palpable here at Monaco!",
    "Every corner, every braking zone - it's all on the line!",
    "This is what Formula 1 is all about, folks!",
    "The crowd is on their feet!",
  ],
}

function BattleCard({ battle, drivers }: { battle: Battle; drivers: Driver[] }) {
  const driver1 = drivers.find(d => d.code === battle.drivers[0])
  const driver2 = drivers.find(d => d.code === battle.drivers[1])

  const battleTypeColors = {
    drs: 'bg-f1-cyan/20 border-f1-cyan',
    'wheel-to-wheel': 'bg-f1-red/20 border-f1-red',
    defending: 'bg-f1-orange/20 border-f1-orange',
  }

  const battleTypeIcons = {
    drs: <Zap className="h-4 w-4 text-f1-cyan" />,
    'wheel-to-wheel': <Flame className="h-4 w-4 text-f1-red" />,
    defending: <Swords className="h-4 w-4 text-f1-orange" />,
  }

  return (
    <div className={cn(
      'rounded-lg border p-4 animate-pulse-glow',
      battleTypeColors[battle.type]
    )}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {battleTypeIcons[battle.type]}
          <span className="text-xs font-bold hud-text uppercase">
            {battle.type.replace('-', ' ')}
          </span>
        </div>
        <span className="text-xs font-mono text-muted-foreground">
          {Math.floor(battle.duration / 60)}:{(battle.duration % 60).toString().padStart(2, '0')}
        </span>
      </div>

      <div className="flex items-center justify-between">
        {/* Driver 1 */}
        <div className="flex items-center gap-2">
          <div 
            className="w-1 h-8 rounded-full"
            style={{ backgroundColor: driver1?.teamColor }}
          />
          <div>
            <span className="font-bold text-lg">{battle.drivers[0]}</span>
            <span className="text-xs text-muted-foreground block">{driver1?.team}</span>
          </div>
        </div>

        {/* Gap */}
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-1">
            <ChevronUp className="h-4 w-4 text-f1-green animate-bounce" />
            <span className="text-2xl font-mono font-bold text-f1-yellow">
              {battle.gap.toFixed(1)}s
            </span>
            <ChevronDown className="h-4 w-4 text-f1-red animate-bounce" />
          </div>
          <span className="text-xs text-muted-foreground">GAP</span>
        </div>

        {/* Driver 2 */}
        <div className="flex items-center gap-2">
          <div className="text-right">
            <span className="font-bold text-lg">{battle.drivers[1]}</span>
            <span className="text-xs text-muted-foreground block">{driver2?.team}</span>
          </div>
          <div 
            className="w-1 h-8 rounded-full"
            style={{ backgroundColor: driver2?.teamColor }}
          />
        </div>
      </div>
    </div>
  )
}

function CommentaryPanel({ commentaries }: { commentaries: Commentary[] }) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [commentaries])

  const typeStyles = {
    exciting: 'text-f1-yellow font-bold animate-data-stream',
    normal: 'text-foreground',
    critical: 'text-f1-red font-bold',
  }

  return (
    <div className="glass-panel rounded-lg overflow-hidden h-full flex flex-col">
      <div className="p-3 border-b border-border flex items-center gap-2">
        <MessageSquare className="h-4 w-4 text-f1-cyan" />
        <h3 className="text-sm font-bold hud-text">LIVE COMMENTARY</h3>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3">
        {commentaries.map((commentary) => (
          <div key={commentary.id} className="flex gap-2">
            <span className="text-xs text-muted-foreground font-mono whitespace-nowrap">
              {commentary.timestamp.toLocaleTimeString()}
            </span>
            <p className={cn('text-sm', typeStyles[commentary.type])}>
              {commentary.text}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

function QuickStats({ drivers }: { drivers: Driver[] }) {
  const leader = drivers[0]
  const fastestLap = [...drivers].sort((a, b) => a.bestLap.localeCompare(b.bestLap))[0]

  return (
    <div className="grid grid-cols-2 gap-3">
      <div className="glass-panel rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Trophy className="h-4 w-4 text-f1-yellow" />
          <span className="text-xs text-muted-foreground hud-text">RACE LEADER</span>
        </div>
        <div className="flex items-center gap-2">
          <div 
            className="w-1 h-8 rounded-full"
            style={{ backgroundColor: leader.teamColor }}
          />
          <div>
            <span className="text-xl font-bold">{leader.code}</span>
            <span className="text-xs text-muted-foreground block">{leader.team}</span>
          </div>
        </div>
      </div>

      <div className="glass-panel rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Zap className="h-4 w-4 text-purple-400" />
          <span className="text-xs text-muted-foreground hud-text">FASTEST LAP</span>
        </div>
        <div className="flex items-center gap-2">
          <div 
            className="w-1 h-8 rounded-full"
            style={{ backgroundColor: fastestLap.teamColor }}
          />
          <div>
            <span className="text-lg font-mono font-bold text-purple-400">{fastestLap.bestLap}</span>
            <span className="text-xs text-muted-foreground block">{fastestLap.code}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export function FanMode({ drivers, battles, events, onDriverSelect, selectedDriverId, className }: FanModeProps) {
  const [commentaries, setCommentaries] = useState<Commentary[]>([])
  const [isMuted, setIsMuted] = useState(true)

  // Generate live commentary
  useEffect(() => {
    const generateCommentary = () => {
      const rand = Math.random()
      let text: string
      let type: Commentary['type'] = 'normal'

      if (rand < 0.3 && battles.length > 0) {
        // Battle commentary
        const battle = battles[Math.floor(Math.random() * battles.length)]
        const templates = commentaryTemplates.battle
        text = templates[Math.floor(Math.random() * templates.length)]
          .replace('{d1}', battle.drivers[0])
          .replace('{d2}', battle.drivers[1])
          .replace('{gap}', battle.gap.toFixed(1))
        type = 'exciting'
      } else if (rand < 0.5) {
        // Fastest lap commentary
        const fastest = [...drivers].sort((a, b) => a.bestLap.localeCompare(b.bestLap))[0]
        const templates = commentaryTemplates.fastest
        text = templates[Math.floor(Math.random() * templates.length)]
          .replace('{driver}', fastest.name)
        type = 'exciting'
      } else {
        // General commentary
        const templates = commentaryTemplates.general
        text = templates[Math.floor(Math.random() * templates.length)]
        type = 'normal'
      }

      const newCommentary: Commentary = {
        id: Date.now().toString(),
        text,
        type,
        timestamp: new Date(),
      }

      setCommentaries(prev => [...prev.slice(-20), newCommentary])

      // Speak if not muted
      if (!isMuted && 'speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text)
        utterance.rate = 1.2
        utterance.pitch = 1.1
        window.speechSynthesis.speak(utterance)
      }
    }

    // Initial commentaries
    if (commentaries.length === 0) {
      generateCommentary()
    }

    const interval = setInterval(generateCommentary, 8000)
    return () => clearInterval(interval)
  }, [battles, drivers, isMuted, commentaries.length])

  // Convert events to commentary
  useEffect(() => {
    if (events.length > 0) {
      const latestEvent = events[0]
      const eventCommentary: Commentary = {
        id: `event-${latestEvent.id}`,
        text: latestEvent.message,
        type: latestEvent.type === 'overtake' || latestEvent.type === 'fastest' ? 'exciting' : 'normal',
        timestamp: new Date(),
      }
      setCommentaries(prev => {
        if (prev.find(c => c.id === eventCommentary.id)) return prev
        return [...prev.slice(-20), eventCommentary]
      })
    }
  }, [events])

  return (
    <div className={cn('flex flex-col gap-4 h-full', className)}>
      {/* Header */}
      <div className="glass-panel rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Flame className="h-5 w-5 text-f1-orange" />
          <h2 className="font-bold hud-text">FAN MODE</h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-f1-red text-background animate-pulse">
            LIVE
          </span>
        </div>
        <button
          onClick={() => setIsMuted(!isMuted)}
          className="p-2 rounded-lg hover:bg-muted transition-colors"
        >
          {isMuted ? (
            <VolumeX className="h-4 w-4 text-muted-foreground" />
          ) : (
            <Volume2 className="h-4 w-4 text-f1-cyan" />
          )}
        </button>
      </div>

      {/* Quick Stats */}
      <QuickStats drivers={drivers} />

      {/* Battles Section */}
      {battles.length > 0 && (
        <div className="glass-panel rounded-lg p-3">
          <div className="flex items-center gap-2 mb-3">
            <Swords className="h-4 w-4 text-f1-orange" />
            <h3 className="text-sm font-bold hud-text">LIVE BATTLES</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-f1-orange/20 text-f1-orange">
              {battles.length} ACTIVE
            </span>
          </div>
          <div className="space-y-3">
            {battles.map((battle) => (
              <BattleCard key={battle.id} battle={battle} drivers={drivers} />
            ))}
          </div>
        </div>
      )}

      {/* Simplified Leaderboard */}
      <DriverLeaderboard
        drivers={drivers}
        onDriverSelect={onDriverSelect}
        selectedDriverId={selectedDriverId}
        simplified
        className="flex-shrink-0"
      />

      {/* Commentary Panel */}
      <div className="flex-1 min-h-[200px]">
        <CommentaryPanel commentaries={commentaries} />
      </div>
    </div>
  )
}
