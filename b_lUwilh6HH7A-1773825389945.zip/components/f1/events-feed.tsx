'use client'

import { useEffect, useRef } from 'react'
import { Flag, Zap, AlertTriangle, ArrowRightLeft, PenTool, Swords } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { RaceEvent } from '@/lib/f1-data'

interface EventsFeedProps {
  events: RaceEvent[]
  className?: string
}

function getEventIcon(type: RaceEvent['type']) {
  const icons = {
    pit: PenTool,
    fastest: Zap,
    flag: Flag,
    overtake: ArrowRightLeft,
    incident: AlertTriangle,
    drs: Zap,
    battle: Swords,
  }
  return icons[type] || Flag
}

function getEventColors(type: RaceEvent['type']) {
  const colors = {
    pit: 'border-f1-yellow text-f1-yellow',
    fastest: 'border-purple-500 text-purple-400',
    flag: 'border-f1-green text-f1-green',
    overtake: 'border-f1-green text-f1-green',
    incident: 'border-f1-yellow text-f1-yellow',
    drs: 'border-f1-cyan text-f1-cyan',
    battle: 'border-f1-orange text-f1-orange',
  }
  return colors[type] || 'border-border text-foreground'
}

export function EventsFeed({ events, className }: EventsFeedProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0
    }
  }, [events])

  return (
    <div className={cn('glass-panel rounded-lg overflow-hidden', className)}>
      <div className="p-3 border-b border-border flex items-center justify-between">
        <h2 className="text-sm font-bold hud-text text-f1-cyan">RACE FEED</h2>
        <span className="text-xs text-muted-foreground font-mono animate-pulse">LIVE</span>
      </div>
      <div ref={scrollRef} className="p-2 space-y-2 max-h-[300px] overflow-y-auto">
        {events.map((event, index) => {
          const Icon = getEventIcon(event.type)
          const colorClass = getEventColors(event.type)

          return (
            <div
              key={event.id}
              className={cn(
                'flex items-start gap-2 p-2 rounded border-l-2 bg-muted/30 transition-all',
                colorClass,
                index === 0 && 'animate-data-stream'
              )}
            >
              <Icon className="h-4 w-4 mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm leading-tight">{event.message}</p>
                <p className="text-xs text-muted-foreground font-mono mt-0.5">{event.time}</p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
