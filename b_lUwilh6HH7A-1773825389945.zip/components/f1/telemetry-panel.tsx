'use client'

import { useMemo } from 'react'
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Area, AreaChart, ComposedChart, Bar } from 'recharts'
import { cn } from '@/lib/utils'
import type { Driver } from '@/lib/f1-data'
import { getTyreColor } from '@/lib/f1-data'

interface TelemetryPanelProps {
  driver: Driver | null
  className?: string
}

// Generate mock telemetry data for visualization
function generateTelemetryData() {
  return Array.from({ length: 50 }, (_, i) => ({
    distance: i * 66,
    speed: 180 + Math.sin(i * 0.2) * 80 + Math.random() * 15,
    throttle: Math.max(0, Math.min(100, 50 + Math.sin(i * 0.2) * 48 + Math.random() * 5)),
    brake: Math.max(0, Math.min(100, Math.cos(i * 0.2) * 45 + Math.random() * 10)),
  }))
}

function SpeedGauge({ speed, maxSpeed = 350 }: { speed: number; maxSpeed?: number }) {
  const percentage = (speed / maxSpeed) * 100
  const circumference = 2 * Math.PI * 45
  const offset = circumference - (percentage / 100) * circumference * 0.75

  return (
    <div className="relative w-32 h-32">
      <svg className="w-full h-full -rotate-135" viewBox="0 0 100 100">
        {/* Background arc */}
        <circle
          cx="50"
          cy="50"
          r="45"
          fill="none"
          stroke="currentColor"
          strokeWidth="6"
          strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
          className="text-muted"
        />
        {/* Progress arc */}
        <circle
          cx="50"
          cy="50"
          r="45"
          fill="none"
          stroke="url(#speedGradient)"
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-all duration-300"
        />
        <defs>
          <linearGradient id="speedGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="oklch(0.7 0.15 195)" />
            <stop offset="50%" stopColor="oklch(0.85 0.18 90)" />
            <stop offset="100%" stopColor="oklch(0.55 0.25 25)" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-mono font-bold text-f1-cyan">{speed}</span>
        <span className="text-xs text-muted-foreground hud-text">KM/H</span>
      </div>
    </div>
  )
}

function GearDisplay({ gear }: { gear: number }) {
  return (
    <div className="flex flex-col items-center">
      <span className="text-xs text-muted-foreground hud-text mb-1">GEAR</span>
      <div className="w-16 h-16 rounded-lg bg-muted border border-border flex items-center justify-center">
        <span className="text-4xl font-mono font-bold text-f1-yellow">{gear}</span>
      </div>
    </div>
  )
}

function ERSBar({ value }: { value: number }) {
  return (
    <div className="flex flex-col gap-1">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground hud-text">ERS</span>
        <span className="font-mono text-f1-cyan">{value}%</span>
      </div>
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div 
          className="h-full bg-gradient-to-r from-f1-blue to-f1-cyan transition-all duration-300"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  )
}

function TyreWearDisplay({ wear, position }: { wear: number; position: string }) {
  const getWearColor = (w: number) => {
    if (w < 30) return 'text-f1-green'
    if (w < 50) return 'text-f1-yellow'
    if (w < 70) return 'text-f1-orange'
    return 'text-f1-red'
  }

  return (
    <div className="flex flex-col items-center">
      <span className="text-[10px] text-muted-foreground">{position}</span>
      <span className={cn('text-sm font-mono font-bold', getWearColor(wear))}>{wear}%</span>
    </div>
  )
}

function SectorTime({ sector, time, status }: { sector: number; time: number; status: 'pb' | 'sb' | 'normal' }) {
  const statusColors = {
    pb: 'bg-f1-green text-background',
    sb: 'bg-purple-500 text-background',
    normal: 'bg-muted text-foreground',
  }

  return (
    <div className={cn('px-3 py-2 rounded text-center', statusColors[status])}>
      <span className="text-xs block mb-1">S{sector}</span>
      <span className="font-mono font-bold">{time.toFixed(3)}</span>
    </div>
  )
}

export function TelemetryPanel({ driver, className }: TelemetryPanelProps) {
  const telemetryData = useMemo(() => generateTelemetryData(), [])

  if (!driver) {
    return (
      <div className={cn('glass-panel rounded-lg p-6 flex items-center justify-center', className)}>
        <p className="text-muted-foreground hud-text">SELECT A DRIVER TO VIEW TELEMETRY</p>
      </div>
    )
  }

  return (
    <div className={cn('glass-panel rounded-lg overflow-hidden', className)}>
      {/* Header */}
      <div className="p-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div 
            className="w-1 h-8 rounded-full"
            style={{ backgroundColor: driver.teamColor }}
          />
          <div>
            <h2 className="text-lg font-bold">{driver.name}</h2>
            <p className="text-xs text-muted-foreground">{driver.team}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-mono font-bold" style={{ color: driver.teamColor }}>#{driver.number}</p>
        </div>
      </div>

      {/* Main Telemetry Grid */}
      <div className="p-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Speed & Gear */}
        <div className="flex items-center justify-around">
          <SpeedGauge speed={driver.speed} />
          <GearDisplay gear={driver.gear} />
        </div>

        {/* RPM Display */}
        <div className="flex flex-col gap-2">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground hud-text">RPM</span>
            <span className="font-mono text-f1-red">{driver.rpm.toLocaleString()}</span>
          </div>
          <div className="h-3 bg-muted rounded-full overflow-hidden flex">
            {Array.from({ length: 10 }).map((_, i) => (
              <div 
                key={i}
                className={cn(
                  'flex-1 border-r border-background last:border-r-0 transition-all',
                  i < Math.floor(driver.rpm / 1200) ? 'bg-f1-red' : 'bg-transparent'
                )}
              />
            ))}
          </div>
          <ERSBar value={driver.ers} />
          <div className="flex justify-between text-xs mt-2">
            <span className="text-muted-foreground hud-text">FUEL</span>
            <span className="font-mono text-f1-yellow">{driver.fuel}%</span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-f1-yellow transition-all duration-300"
              style={{ width: `${driver.fuel}%` }}
            />
          </div>
        </div>

        {/* Throttle/Brake */}
        <div className="flex flex-col gap-2">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground hud-text">THROTTLE</span>
            <span className="font-mono text-f1-green">{driver.throttle}%</span>
          </div>
          <div className="h-3 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-f1-green transition-all duration-300"
              style={{ width: `${driver.throttle}%` }}
            />
          </div>
          <div className="flex justify-between text-xs mt-2">
            <span className="text-muted-foreground hud-text">BRAKE</span>
            <span className="font-mono text-f1-red">{driver.brake}%</span>
          </div>
          <div className="h-3 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-f1-red transition-all duration-300"
              style={{ width: `${driver.brake}%` }}
            />
          </div>
        </div>
      </div>

      {/* Speed Graph */}
      <div className="px-4 pb-2">
        <p className="text-xs text-muted-foreground hud-text mb-2">SPEED TRACE</p>
        <div className="h-24">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={telemetryData}>
              <defs>
                <linearGradient id="speedGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.7 0.15 195)" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="oklch(0.7 0.15 195)" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Area 
                type="monotone" 
                dataKey="speed" 
                stroke="oklch(0.7 0.15 195)" 
                strokeWidth={2}
                fill="url(#speedGrad)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Throttle/Brake Graph */}
      <div className="px-4 pb-4">
        <p className="text-xs text-muted-foreground hud-text mb-2">THROTTLE / BRAKE</p>
        <div className="h-20">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={telemetryData}>
              <Area 
                type="monotone" 
                dataKey="throttle" 
                stroke="oklch(0.65 0.2 145)" 
                strokeWidth={1.5}
                fill="oklch(0.65 0.2 145 / 0.2)" 
              />
              <Area 
                type="monotone" 
                dataKey="brake" 
                stroke="oklch(0.55 0.25 25)" 
                strokeWidth={1.5}
                fill="oklch(0.55 0.25 25 / 0.2)" 
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Tyre Wear & Sectors */}
      <div className="px-4 pb-4 grid grid-cols-2 gap-4">
        {/* Tyre Wear */}
        <div className="glass-panel rounded-lg p-3">
          <p className="text-xs text-muted-foreground hud-text mb-2 text-center">TYRE WEAR</p>
          <div 
            className="w-6 h-6 rounded-full mx-auto mb-2 border-2"
            style={{ borderColor: getTyreColor(driver.tyre) }}
          >
            <span className="text-[8px] font-bold flex items-center justify-center h-full" style={{ color: getTyreColor(driver.tyre) }}>
              {driver.tyre.charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <TyreWearDisplay wear={driver.tyreWear.fl} position="FL" />
            <TyreWearDisplay wear={driver.tyreWear.fr} position="FR" />
            <TyreWearDisplay wear={driver.tyreWear.rl} position="RL" />
            <TyreWearDisplay wear={driver.tyreWear.rr} position="RR" />
          </div>
        </div>

        {/* Sector Times */}
        <div className="glass-panel rounded-lg p-3">
          <p className="text-xs text-muted-foreground hud-text mb-2 text-center">SECTOR TIMES</p>
          <div className="flex flex-col gap-2">
            <SectorTime sector={1} time={driver.sectorTimes.s1} status={driver.sectorStatus.s1} />
            <SectorTime sector={2} time={driver.sectorTimes.s2} status={driver.sectorStatus.s2} />
            <SectorTime sector={3} time={driver.sectorTimes.s3} status={driver.sectorStatus.s3} />
          </div>
        </div>
      </div>

      {/* Lap Times */}
      <div className="px-4 pb-4">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-xs text-muted-foreground">LAST LAP</p>
            <p className="text-xl font-mono font-bold">{driver.lastLap}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">BEST LAP</p>
            <p className="text-xl font-mono font-bold text-purple-400">{driver.bestLap}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
