'use client'

import { Headphones, Users, Play, LayoutDashboard } from 'lucide-react'
import { cn } from '@/lib/utils'

export type DashboardMode = 'dashboard' | 'engineer' | 'fan' | 'simulation'

interface ModeSelectorProps {
  currentMode: DashboardMode
  onModeChange: (mode: DashboardMode) => void
  className?: string
}

const modes = [
  {
    id: 'dashboard' as DashboardMode,
    label: 'RACE CONTROL',
    icon: LayoutDashboard,
    color: 'text-f1-cyan',
    bgActive: 'bg-f1-cyan',
    description: 'Full telemetry view',
  },
  {
    id: 'engineer' as DashboardMode,
    label: 'ENGINEER',
    icon: Headphones,
    color: 'text-f1-red',
    bgActive: 'bg-f1-red',
    description: 'Voice commands & AI',
  },
  {
    id: 'fan' as DashboardMode,
    label: 'FAN',
    icon: Users,
    color: 'text-f1-orange',
    bgActive: 'bg-f1-orange',
    description: 'Battles & commentary',
  },
  {
    id: 'simulation' as DashboardMode,
    label: 'SIMULATION',
    icon: Play,
    color: 'text-f1-purple',
    bgActive: 'bg-f1-purple',
    description: 'Replay & predictions',
  },
]

export function ModeSelector({ currentMode, onModeChange, className }: ModeSelectorProps) {
  return (
    <div className={cn('flex gap-2', className)}>
      {modes.map((mode) => {
        const Icon = mode.icon
        const isActive = currentMode === mode.id

        return (
          <button
            key={mode.id}
            onClick={() => onModeChange(mode.id)}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200',
              'border border-transparent',
              isActive 
                ? `${mode.bgActive} text-background border-transparent` 
                : 'bg-muted/50 hover:bg-muted text-foreground hover:border-border'
            )}
          >
            <Icon className={cn('h-4 w-4', !isActive && mode.color)} />
            <div className="hidden sm:block text-left">
              <span className="text-xs font-bold hud-text block">{mode.label}</span>
              <span className={cn(
                'text-[10px]',
                isActive ? 'text-background/70' : 'text-muted-foreground'
              )}>
                {mode.description}
              </span>
            </div>
          </button>
        )
      })}
    </div>
  )
}
