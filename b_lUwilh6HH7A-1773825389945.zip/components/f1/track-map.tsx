'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import type { Driver } from '@/lib/f1-data'

interface TrackMapProps {
  drivers: Driver[]
  selectedDriverId?: string
  className?: string
}

// Monaco circuit coordinates (simplified)
const trackPath = `
  M 50,10 
  C 80,10 95,25 95,50 
  C 95,65 85,75 75,80 
  L 70,82 
  C 60,85 50,90 40,90 
  C 20,90 10,75 10,55 
  C 10,35 20,20 35,15 
  L 50,10
`

// Generate positions around the track
function getDriverPosition(index: number, total: number): { x: number; y: number } {
  const angle = (index / total) * Math.PI * 2 - Math.PI / 2
  const radiusX = 35
  const radiusY = 35
  return {
    x: 50 + Math.cos(angle) * radiusX + (Math.random() - 0.5) * 5,
    y: 50 + Math.sin(angle) * radiusY + (Math.random() - 0.5) * 5,
  }
}

export function TrackMap({ drivers, selectedDriverId, className }: TrackMapProps) {
  const [positions, setPositions] = useState<Map<string, { x: number; y: number }>>(new Map())

  useEffect(() => {
    const newPositions = new Map<string, { x: number; y: number }>()
    drivers.forEach((driver, index) => {
      newPositions.set(driver.id, getDriverPosition(index, drivers.length))
    })
    setPositions(newPositions)

    // Animate positions
    const interval = setInterval(() => {
      setPositions(prev => {
        const updated = new Map(prev)
        drivers.forEach((driver) => {
          const current = updated.get(driver.id)
          if (current) {
            updated.set(driver.id, {
              x: current.x + (Math.random() - 0.5) * 2,
              y: current.y + (Math.random() - 0.5) * 2,
            })
          }
        })
        return updated
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [drivers])

  return (
    <div className={cn('glass-panel rounded-lg p-4', className)}>
      <h3 className="text-xs text-muted-foreground hud-text mb-3">TRACK MAP - MONACO</h3>
      <div className="relative aspect-square max-w-[300px] mx-auto">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {/* Track outline */}
          <path
            d={trackPath}
            fill="none"
            stroke="oklch(0.3 0.02 260)"
            strokeWidth="8"
            strokeLinecap="round"
          />
          <path
            d={trackPath}
            fill="none"
            stroke="oklch(0.18 0.01 260)"
            strokeWidth="6"
            strokeLinecap="round"
          />

          {/* Sector markers */}
          <circle cx="72" cy="25" r="2" fill="oklch(0.55 0.25 25)" />
          <circle cx="25" cy="75" r="2" fill="oklch(0.55 0.25 25)" />
          <circle cx="50" cy="10" r="2" fill="oklch(0.55 0.25 25)" />

          {/* DRS Zones */}
          <path
            d="M 50,10 C 80,10 95,25 95,40"
            fill="none"
            stroke="oklch(0.7 0.15 195 / 0.3)"
            strokeWidth="3"
            strokeDasharray="4 2"
          />

          {/* Driver positions */}
          {drivers.map((driver) => {
            const pos = positions.get(driver.id)
            if (!pos) return null
            const isSelected = selectedDriverId === driver.id

            return (
              <g key={driver.id}>
                {/* Glow effect for selected */}
                {isSelected && (
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r="6"
                    fill="none"
                    stroke={driver.teamColor}
                    strokeWidth="1"
                    opacity="0.5"
                    className="animate-ping"
                  />
                )}
                {/* Driver dot */}
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r={isSelected ? "4" : "3"}
                  fill={driver.teamColor}
                  className="transition-all duration-300"
                />
                {/* Driver code */}
                {isSelected && (
                  <text
                    x={pos.x}
                    y={pos.y - 6}
                    fontSize="4"
                    fill="white"
                    textAnchor="middle"
                    className="font-mono font-bold"
                  >
                    {driver.code}
                  </text>
                )}
              </g>
            )
          })}

          {/* Start/Finish line */}
          <line
            x1="45"
            y1="8"
            x2="55"
            y2="8"
            stroke="white"
            strokeWidth="1"
            strokeDasharray="1 1"
          />
        </svg>

        {/* Legend */}
        <div className="absolute bottom-0 left-0 right-0 flex justify-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-f1-red rounded-full" />
            <span className="text-muted-foreground">Sectors</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-4 h-0.5 bg-f1-cyan opacity-50" />
            <span className="text-muted-foreground">DRS</span>
          </div>
        </div>
      </div>
    </div>
  )
}
