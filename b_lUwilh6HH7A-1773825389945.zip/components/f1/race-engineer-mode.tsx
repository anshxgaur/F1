'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Mic, MicOff, Bot, Send, Volume2, Lightbulb, AlertCircle, TrendingUp, Fuel, CircleDot } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import type { Driver, AIPrediction } from '@/lib/f1-data'

interface RaceEngineerModeProps {
  drivers: Driver[]
  predictions: AIPrediction[]
  onDriverSelect: (driver: Driver) => void
  className?: string
}

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
  action?: string
}

interface VoiceCommand {
  pattern: RegExp
  action: string
  response: (match: RegExpMatchArray, drivers: Driver[]) => string
}

const voiceCommands: VoiceCommand[] = [
  {
    pattern: /show (\w+) telemetry/i,
    action: 'showTelemetry',
    response: (match, drivers) => {
      const code = match[1].toUpperCase()
      const driver = drivers.find(d => d.code === code || d.name.toLowerCase().includes(match[1].toLowerCase()))
      if (driver) {
        return `Displaying telemetry for ${driver.name}. Current speed: ${driver.speed} km/h, Gear ${driver.gear}, Tyre wear averaging ${Math.round((driver.tyreWear.fl + driver.tyreWear.fr + driver.tyreWear.rl + driver.tyreWear.rr) / 4)}%.`
      }
      return `Driver ${match[1]} not found. Try using driver codes like VER, HAM, or LEC.`
    }
  },
  {
    pattern: /pit strategy(?: for)? (\w+)?/i,
    action: 'pitStrategy',
    response: (match, drivers) => {
      const code = match[1]?.toUpperCase()
      const driver = code ? drivers.find(d => d.code === code) : drivers[0]
      if (driver) {
        const avgWear = Math.round((driver.tyreWear.fl + driver.tyreWear.fr + driver.tyreWear.rl + driver.tyreWear.rr) / 4)
        if (avgWear > 60) {
          return `RECOMMENDATION: ${driver.code} should pit within 3-5 laps. Tyre degradation at ${avgWear}%. Suggest switching to ${driver.tyre === 'medium' ? 'hard' : 'soft'} compound for optimal pace.`
        }
        return `${driver.code}'s tyres at ${avgWear}% wear. Current stint is sustainable for another 10-12 laps. No immediate pit required.`
      }
      return "Unable to analyze pit strategy. Please specify a driver."
    }
  },
  {
    pattern: /gap to leader(?: for)? (\w+)?/i,
    action: 'gapToLeader',
    response: (match, drivers) => {
      const code = match[1]?.toUpperCase()
      const driver = code ? drivers.find(d => d.code === code) : drivers[1]
      if (driver) {
        return `${driver.code} is ${driver.gap} to the leader. ${driver.delta < 0 ? `Gaining ${Math.abs(driver.delta).toFixed(3)}s per lap` : driver.delta > 0 ? `Losing ${driver.delta.toFixed(3)}s per lap` : 'Pace is stable'}.`
      }
      return "Driver not found."
    }
  },
  {
    pattern: /weather update/i,
    action: 'weather',
    response: () => "Current conditions: Dry track, 24°C air, 38°C track temperature. 0% rain probability in the next 30 minutes. Wind 8 km/h from SW."
  },
  {
    pattern: /race status/i,
    action: 'raceStatus',
    response: (_, drivers) => {
      const leader = drivers[0]
      return `Lap 42 of 78. ${leader.code} leads by ${drivers[1].gap.replace('+', '')}. Green flag conditions. DRS enabled in all zones. Top 3: ${drivers.slice(0, 3).map(d => d.code).join(', ')}.`
    }
  },
  {
    pattern: /fastest lap/i,
    action: 'fastestLap',
    response: (_, drivers) => {
      const fastest = [...drivers].sort((a, b) => a.bestLap.localeCompare(b.bestLap))[0]
      return `Fastest lap: ${fastest.bestLap} by ${fastest.code}. Purple sectors in S1 and S3. This lap was set on ${fastest.tyre} compound, lap ${fastest.tyreAge} of the stint.`
    }
  },
  {
    pattern: /compare (\w+) (?:and|vs) (\w+)/i,
    action: 'compare',
    response: (match, drivers) => {
      const d1 = drivers.find(d => d.code === match[1].toUpperCase())
      const d2 = drivers.find(d => d.code === match[2].toUpperCase())
      if (d1 && d2) {
        const gap = parseFloat(d2.gap.replace('+', '')) - parseFloat(d1.gap === 'LEADER' ? '0' : d1.gap.replace('+', ''))
        return `${d1.code} vs ${d2.code}: Gap ${Math.abs(gap).toFixed(3)}s. ${d1.code} has ${d1.tyre} (${d1.tyreAge} laps), ${d2.code} has ${d2.tyre} (${d2.tyreAge} laps). Pace advantage: ${d1.delta < d2.delta ? d1.code : d2.code}.`
      }
      return "One or both drivers not found."
    }
  },
  {
    pattern: /tyre status(?: for)? (\w+)?/i,
    action: 'tyreStatus',
    response: (match, drivers) => {
      const code = match[1]?.toUpperCase()
      const driver = code ? drivers.find(d => d.code === code) : drivers[0]
      if (driver) {
        return `${driver.code} tyre status: ${driver.tyre.toUpperCase()} compound, ${driver.tyreAge} laps old. Wear: FL ${driver.tyreWear.fl}%, FR ${driver.tyreWear.fr}%, RL ${driver.tyreWear.rl}%, RR ${driver.tyreWear.rr}%. ${driver.tyreWear.fr > 50 ? 'Front right showing increased degradation.' : 'Balanced wear across all four corners.'}`
      }
      return "Driver not found."
    }
  },
]

function StrategyCard({ prediction, driver }: { prediction: AIPrediction; driver?: Driver }) {
  const riskColors = {
    low: 'text-f1-green border-f1-green/30',
    medium: 'text-f1-yellow border-f1-yellow/30',
    high: 'text-f1-red border-f1-red/30',
  }

  return (
    <div className={cn('p-3 rounded-lg border bg-muted/30', riskColors[prediction.riskLevel])}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div 
            className="w-1 h-6 rounded-full"
            style={{ backgroundColor: driver?.teamColor || '#fff' }}
          />
          <span className="font-bold">{driver?.code || prediction.driverId.toUpperCase()}</span>
        </div>
        <span className="text-xs px-2 py-0.5 rounded-full bg-background">
          P{prediction.predictedPosition} ({prediction.confidence}%)
        </span>
      </div>
      <p className="text-sm text-muted-foreground">{prediction.pitStrategy}</p>
      <div className="mt-2 flex items-center gap-1 text-xs">
        <AlertCircle className="h-3 w-3" />
        <span>Risk: {prediction.riskLevel}</span>
      </div>
    </div>
  )
}

export function RaceEngineerMode({ drivers, predictions, onDriverSelect, className }: RaceEngineerModeProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Race Engineer AI online. I can help with telemetry analysis, pit strategies, and race insights. Try voice commands like "Show Hamilton telemetry" or "Pit strategy for VER".',
      timestamp: new Date(),
    }
  ])
  const [input, setInput] = useState('')
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = false
      recognitionRef.current.interimResults = false
      recognitionRef.current.lang = 'en-US'

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript
        handleCommand(transcript)
      }

      recognitionRef.current.onend = () => {
        setIsListening(false)
      }

      recognitionRef.current.onerror = () => {
        setIsListening(false)
      }
    }
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const speakResponse = useCallback((text: string) => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true)
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = 1.1
      utterance.pitch = 0.9
      utterance.onend = () => setIsSpeaking(false)
      window.speechSynthesis.speak(utterance)
    }
  }, [])

  const handleCommand = useCallback((text: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date(),
    }
    setMessages(prev => [...prev, userMessage])

    // Process command
    let response = "I didn't understand that command. Try asking about telemetry, pit strategy, gaps, weather, or race status."
    let action: string | undefined

    for (const cmd of voiceCommands) {
      const match = text.match(cmd.pattern)
      if (match) {
        response = cmd.response(match, drivers)
        action = cmd.action

        // Handle driver selection for telemetry
        if (cmd.action === 'showTelemetry' && match[1]) {
          const driver = drivers.find(d => 
            d.code === match[1].toUpperCase() || 
            d.name.toLowerCase().includes(match[1].toLowerCase())
          )
          if (driver) {
            onDriverSelect(driver)
          }
        }
        break
      }
    }

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: response,
      timestamp: new Date(),
      action,
    }

    setTimeout(() => {
      setMessages(prev => [...prev, assistantMessage])
      speakResponse(response)
    }, 500)
  }, [drivers, onDriverSelect, speakResponse])

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop()
      setIsListening(false)
    } else {
      recognitionRef.current?.start()
      setIsListening(true)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim()) {
      handleCommand(input.trim())
      setInput('')
    }
  }

  return (
    <div className={cn('flex flex-col h-full', className)}>
      {/* Header */}
      <div className="glass-panel rounded-lg p-3 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-f1-cyan" />
            <h2 className="font-bold hud-text">RACE ENGINEER AI</h2>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={toggleListening}
              className={cn(
                'gap-2',
                isListening && 'bg-f1-red text-background border-f1-red animate-pulse'
              )}
            >
              {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              {isListening ? 'LISTENING...' : 'VOICE'}
            </Button>
            {isSpeaking && (
              <Volume2 className="h-4 w-4 text-f1-cyan animate-pulse" />
            )}
          </div>
        </div>
      </div>

      {/* Strategy Predictions */}
      <div className="glass-panel rounded-lg p-3 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="h-4 w-4 text-f1-yellow" />
          <h3 className="text-sm font-bold hud-text">AI STRATEGY INSIGHTS</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-[200px] overflow-y-auto">
          {predictions.slice(0, 4).map((prediction) => (
            <StrategyCard 
              key={prediction.driverId} 
              prediction={prediction}
              driver={drivers.find(d => d.id === prediction.driverId)}
            />
          ))}
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 glass-panel rounded-lg overflow-hidden flex flex-col">
        <div className="p-3 border-b border-border">
          <h3 className="text-sm font-bold hud-text text-f1-cyan">COMMAND CENTER</h3>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                'flex',
                message.role === 'user' ? 'justify-end' : 'justify-start'
              )}
            >
              <div
                className={cn(
                  'max-w-[80%] rounded-lg p-3',
                  message.role === 'user'
                    ? 'bg-f1-cyan text-background'
                    : 'bg-muted border border-border'
                )}
              >
                <p className="text-sm">{message.content}</p>
                <p className={cn(
                  'text-xs mt-1',
                  message.role === 'user' ? 'text-background/70' : 'text-muted-foreground'
                )}>
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <form onSubmit={handleSubmit} className="p-3 border-t border-border">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a command or question..."
              className="flex-1 bg-muted border-border"
            />
            <Button type="submit" size="icon" className="bg-f1-red hover:bg-f1-red/80">
              <Send className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {['Show VER telemetry', 'Pit strategy', 'Weather update', 'Compare HAM vs LEC'].map((cmd) => (
              <button
                key={cmd}
                type="button"
                onClick={() => handleCommand(cmd)}
                className="text-xs px-2 py-1 rounded-full bg-muted hover:bg-muted/80 text-muted-foreground transition-colors"
              >
                {cmd}
              </button>
            ))}
          </div>
        </form>
      </div>
    </div>
  )
}
