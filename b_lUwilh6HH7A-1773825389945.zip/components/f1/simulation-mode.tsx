'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Play, Pause, SkipBack, SkipForward, RefreshCw, Brain, TrendingUp, Percent, ChevronRight, FastForward } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, AreaChart, Area, Tooltip, Legend, BarChart, Bar, Cell } from 'recharts'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { cn } from '@/lib/utils'
import type { Driver, TelemetryPoint } from '@/lib/f1-data'

interface SimulationModeProps {
  drivers: Driver[]
  historicalLaps: TelemetryPoint[][]
  className?: string
}

interface PredictionResult {
  driverId: string
  driverCode: string
  teamColor: string
  currentPosition: number
  predictedPosition: number
  winProbability: number
  podiumProbability: number
  pointsProbability: number
  factors: string[]
}

// Generate AI predictions based on current race state
function generatePredictions(drivers: Driver[]): PredictionResult[] {
  return drivers.slice(0, 10).map((driver, index) => {
    const baseWinProb = Math.max(0, 100 - index * 15 - Math.random() * 10)
    const podiumProb = Math.min(100, baseWinProb + 30 + Math.random() * 20)
    const pointsProb = Math.min(100, podiumProb + 40 + Math.random() * 20)

    // Predict slight position changes
    let predictedPosition = driver.position
    if (Math.random() > 0.7) {
      predictedPosition = Math.max(1, Math.min(20, predictedPosition + (Math.random() > 0.5 ? 1 : -1)))
    }

    const factors: string[] = []
    if (driver.delta < 0) factors.push('Strong current pace')
    if (driver.tyreAge < 10) factors.push('Fresh tyres')
    if (driver.ers > 70) factors.push('Good ERS deployment')
    if (driver.fuel < 30) factors.push('Light fuel load')
    if (driver.tyreWear.fr > 50) factors.push('High tyre wear')
    if (driver.position <= 3) factors.push('Track position advantage')

    return {
      driverId: driver.id,
      driverCode: driver.code,
      teamColor: driver.teamColor,
      currentPosition: driver.position,
      predictedPosition,
      winProbability: Math.round(baseWinProb),
      podiumProbability: Math.round(podiumProb),
      pointsProbability: Math.round(pointsProb),
      factors: factors.slice(0, 3),
    }
  })
}

function ReplayControls({ 
  isPlaying, 
  onPlayPause, 
  onReset, 
  currentLap, 
  maxLap,
  onLapChange,
  playbackSpeed,
  onSpeedChange,
}: {
  isPlaying: boolean
  onPlayPause: () => void
  onReset: () => void
  currentLap: number
  maxLap: number
  onLapChange: (lap: number) => void
  playbackSpeed: number
  onSpeedChange: (speed: number) => void
}) {
  return (
    <div className="glass-panel rounded-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-bold hud-text text-f1-cyan">LAP REPLAY</h3>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">SPEED:</span>
          {[0.5, 1, 2, 4].map((speed) => (
            <button
              key={speed}
              onClick={() => onSpeedChange(speed)}
              className={cn(
                'text-xs px-2 py-1 rounded',
                playbackSpeed === speed ? 'bg-f1-cyan text-background' : 'bg-muted text-muted-foreground'
              )}
            >
              {speed}x
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={onReset}>
          <SkipBack className="h-4 w-4" />
        </Button>
        <Button 
          size="icon" 
          onClick={onPlayPause}
          className={cn(
            isPlaying ? 'bg-f1-red hover:bg-f1-red/80' : 'bg-f1-green hover:bg-f1-green/80'
          )}
        >
          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </Button>
        <Button variant="outline" size="icon" onClick={() => onLapChange(Math.min(maxLap, currentLap + 1))}>
          <SkipForward className="h-4 w-4" />
        </Button>

        <div className="flex-1 flex items-center gap-3">
          <span className="text-sm font-mono text-muted-foreground">LAP {currentLap}</span>
          <Slider
            value={[currentLap]}
            min={1}
            max={maxLap}
            step={1}
            onValueChange={([lap]) => onLapChange(lap)}
            className="flex-1"
          />
          <span className="text-sm font-mono text-muted-foreground">LAP {maxLap}</span>
        </div>
      </div>
    </div>
  )
}

function TelemetryReplay({ 
  data, 
  currentIndex 
}: { 
  data: TelemetryPoint[]
  currentIndex: number 
}) {
  const visibleData = data.slice(0, currentIndex + 1)

  return (
    <div className="glass-panel rounded-lg p-4">
      <h3 className="text-sm font-bold hud-text text-f1-cyan mb-3">TELEMETRY REPLAY</h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Speed trace */}
        <div>
          <p className="text-xs text-muted-foreground mb-2">SPEED (KM/H)</p>
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={visibleData}>
                <defs>
                  <linearGradient id="speedGradReplay" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.7 0.15 195)" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="oklch(0.7 0.15 195)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="distance" hide />
                <YAxis domain={[100, 350]} hide />
                <Area 
                  type="monotone" 
                  dataKey="speed" 
                  stroke="oklch(0.7 0.15 195)" 
                  strokeWidth={2}
                  fill="url(#speedGradReplay)" 
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Throttle/Brake */}
        <div>
          <p className="text-xs text-muted-foreground mb-2">THROTTLE / BRAKE</p>
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={visibleData}>
                <XAxis dataKey="distance" hide />
                <YAxis domain={[0, 100]} hide />
                <Area 
                  type="monotone" 
                  dataKey="throttle" 
                  stroke="oklch(0.65 0.2 145)" 
                  strokeWidth={1.5}
                  fill="oklch(0.65 0.2 145 / 0.2)" 
                  isAnimationActive={false}
                />
                <Area 
                  type="monotone" 
                  dataKey="brake" 
                  stroke="oklch(0.55 0.25 25)" 
                  strokeWidth={1.5}
                  fill="oklch(0.55 0.25 25 / 0.2)" 
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Current values */}
      {visibleData.length > 0 && (
        <div className="mt-4 grid grid-cols-4 gap-4">
          <div className="text-center">
            <span className="text-xs text-muted-foreground">SPEED</span>
            <p className="text-xl font-mono font-bold text-f1-cyan">
              {Math.round(visibleData[visibleData.length - 1].speed)}
            </p>
          </div>
          <div className="text-center">
            <span className="text-xs text-muted-foreground">THROTTLE</span>
            <p className="text-xl font-mono font-bold text-f1-green">
              {Math.round(visibleData[visibleData.length - 1].throttle)}%
            </p>
          </div>
          <div className="text-center">
            <span className="text-xs text-muted-foreground">BRAKE</span>
            <p className="text-xl font-mono font-bold text-f1-red">
              {Math.round(visibleData[visibleData.length - 1].brake)}%
            </p>
          </div>
          <div className="text-center">
            <span className="text-xs text-muted-foreground">GEAR</span>
            <p className="text-xl font-mono font-bold text-f1-yellow">
              {visibleData[visibleData.length - 1].gear}
            </p>
          </div>
        </div>
      )}
    </div>
  )
}

function PredictionCard({ prediction }: { prediction: PredictionResult }) {
  const positionChange = prediction.currentPosition - prediction.predictedPosition

  return (
    <div className="glass-panel rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div 
            className="w-1 h-8 rounded-full"
            style={{ backgroundColor: prediction.teamColor }}
          />
          <div>
            <span className="font-bold text-lg">{prediction.driverCode}</span>
            <div className="flex items-center gap-1 text-xs">
              <span className="text-muted-foreground">P{prediction.currentPosition}</span>
              {positionChange !== 0 && (
                <>
                  <ChevronRight className="h-3 w-3 text-muted-foreground" />
                  <span className={cn(
                    'font-bold',
                    positionChange > 0 ? 'text-f1-green' : 'text-f1-red'
                  )}>
                    P{prediction.predictedPosition}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
        <div className="text-right">
          <span className="text-2xl font-mono font-bold text-f1-yellow">
            {prediction.winProbability}%
          </span>
          <span className="text-xs text-muted-foreground block">WIN</span>
        </div>
      </div>

      {/* Probability bars */}
      <div className="space-y-2">
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-muted-foreground">Podium</span>
            <span className="font-mono">{prediction.podiumProbability}%</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-f1-orange transition-all duration-500"
              style={{ width: `${prediction.podiumProbability}%` }}
            />
          </div>
        </div>
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-muted-foreground">Points</span>
            <span className="font-mono">{prediction.pointsProbability}%</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-f1-green transition-all duration-500"
              style={{ width: `${prediction.pointsProbability}%` }}
            />
          </div>
        </div>
      </div>

      {/* Key factors */}
      {prediction.factors.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1">
          {prediction.factors.map((factor, i) => (
            <span 
              key={i}
              className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground"
            >
              {factor}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

function WinProbabilityChart({ predictions }: { predictions: PredictionResult[] }) {
  const data = predictions.slice(0, 6).map(p => ({
    name: p.driverCode,
    probability: p.winProbability,
    color: p.teamColor,
  }))

  return (
    <div className="glass-panel rounded-lg p-4">
      <div className="flex items-center gap-2 mb-3">
        <TrendingUp className="h-4 w-4 text-f1-cyan" />
        <h3 className="text-sm font-bold hud-text">WIN PROBABILITY</h3>
      </div>
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical">
            <XAxis type="number" domain={[0, 100]} hide />
            <YAxis type="category" dataKey="name" width={40} tick={{ fill: '#888', fontSize: 12 }} />
            <Bar dataKey="probability" radius={[0, 4, 4, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export function SimulationMode({ drivers, historicalLaps, className }: SimulationModeProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentLap, setCurrentLap] = useState(1)
  const [currentDataIndex, setCurrentDataIndex] = useState(0)
  const [playbackSpeed, setPlaybackSpeed] = useState(1)
  const [predictions, setPredictions] = useState<PredictionResult[]>([])
  const [isGeneratingPredictions, setIsGeneratingPredictions] = useState(false)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  const maxLap = historicalLaps.length
  const currentLapData = historicalLaps[currentLap - 1] || []

  // Generate initial predictions
  useEffect(() => {
    setPredictions(generatePredictions(drivers))
  }, [drivers])

  // Playback logic
  useEffect(() => {
    if (isPlaying && currentLapData.length > 0) {
      intervalRef.current = setInterval(() => {
        setCurrentDataIndex(prev => {
          if (prev >= currentLapData.length - 1) {
            if (currentLap < maxLap) {
              setCurrentLap(l => l + 1)
              return 0
            } else {
              setIsPlaying(false)
              return prev
            }
          }
          return prev + 1
        })
      }, 100 / playbackSpeed)
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isPlaying, playbackSpeed, currentLapData.length, currentLap, maxLap])

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  const handleReset = () => {
    setIsPlaying(false)
    setCurrentLap(1)
    setCurrentDataIndex(0)
  }

  const handleLapChange = (lap: number) => {
    setCurrentLap(lap)
    setCurrentDataIndex(0)
  }

  const regeneratePredictions = useCallback(() => {
    setIsGeneratingPredictions(true)
    setTimeout(() => {
      setPredictions(generatePredictions(drivers))
      setIsGeneratingPredictions(false)
    }, 1500)
  }, [drivers])

  return (
    <div className={cn('flex flex-col gap-4 h-full overflow-y-auto', className)}>
      {/* Header */}
      <div className="glass-panel rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-f1-purple" />
          <h2 className="font-bold hud-text">SIMULATION MODE</h2>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={regeneratePredictions}
          disabled={isGeneratingPredictions}
          className="gap-2"
        >
          <RefreshCw className={cn('h-4 w-4', isGeneratingPredictions && 'animate-spin')} />
          {isGeneratingPredictions ? 'ANALYZING...' : 'REFRESH AI'}
        </Button>
      </div>

      {/* Replay Controls */}
      <ReplayControls
        isPlaying={isPlaying}
        onPlayPause={handlePlayPause}
        onReset={handleReset}
        currentLap={currentLap}
        maxLap={maxLap}
        onLapChange={handleLapChange}
        playbackSpeed={playbackSpeed}
        onSpeedChange={setPlaybackSpeed}
      />

      {/* Telemetry Replay */}
      <TelemetryReplay data={currentLapData} currentIndex={currentDataIndex} />

      {/* AI Predictions Section */}
      <div className="glass-panel rounded-lg p-3">
        <div className="flex items-center gap-2 mb-3">
          <Brain className="h-4 w-4 text-f1-purple" />
          <h3 className="text-sm font-bold hud-text">AI RACE PREDICTIONS</h3>
          {isGeneratingPredictions && (
            <span className="text-xs text-f1-cyan animate-pulse">Processing...</span>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Win Probability Chart */}
          <WinProbabilityChart predictions={predictions} />

          {/* Top Predictions */}
          <div className="space-y-3">
            {predictions.slice(0, 3).map((prediction) => (
              <PredictionCard key={prediction.driverId} prediction={prediction} />
            ))}
          </div>
        </div>
      </div>

      {/* All Driver Predictions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {predictions.slice(3).map((prediction) => (
          <PredictionCard key={prediction.driverId} prediction={prediction} />
        ))}
      </div>
    </div>
  )
}
