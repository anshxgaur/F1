'use client'

import { useState } from 'react'
import { ChevronUp, ChevronDown, Minus, Circle } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Driver, TyreCompound } from '@/lib/f1-data'
import { getTyreColor } from '@/lib/f1-data'

interface DriverLeaderboardProps {
  drivers: Driver[]
  onDriverSelect: (driver: Driver) => void
  selectedDriverId?: string
  simplified?: boolean
  className?: string
}

function TyreIndicator({ compound, age }: { compound: TyreCompound; age: number }) {
  const color = getTyreColor(compound)
  return (
    <div className="flex items-center gap-1">
      <div 
        className="w-4 h-4 rounded-full border-2 flex items-center justify-center"
        style={{ borderColor: color }}
      >
        <span className="text-[8px] font-bold" style={{ color }}>
          {compound.charAt(0).toUpperCase()}
        </span>
      </div>
      <span className="text-xs text-muted-foreground font-mono">{age}</span>
    </div>
  )
}

function DeltaIndicator({ delta }: { delta: number }) {
  if (delta === 0) {
    return <Minus className="h-3 w-3 text-muted-foreground" />
  }
  if (delta < 0) {
    return (
      <div className="flex items-center text-f1-green">
        <ChevronUp className="h-3 w-3" />
        <span className="text-xs font-mono">{Math.abs(delta).toFixed(3)}</span>
      </div>
    )
  }
  return (
    <div className="flex items-center text-f1-red">
      <ChevronDown className="h-3 w-3" />
      <span className="text-xs font-mono">{delta.toFixed(3)}</span>
    </div>
  )
}

export function DriverLeaderboard({ 
  drivers, 
  onDriverSelect, 
  selectedDriverId,
  simplified = false,
  className 
}: DriverLeaderboardProps) {
  const [hoveredDriver, setHoveredDriver] = useState<string | null>(null)

  return (
    <div className={cn('glass-panel rounded-lg overflow-hidden', className)}>
      <div className="p-3 border-b border-border">
        <h2 className="text-sm font-bold hud-text text-f1-cyan">LIVE STANDINGS</h2>
      </div>
      <div className="overflow-auto max-h-[calc(100vh-300px)]">
        <table className="w-full">
          <thead className="bg-muted/30 sticky top-0">
            <tr className="text-xs text-muted-foreground hud-text">
              <th className="px-2 py-2 text-left">POS</th>
              <th className="px-2 py-2 text-left">DRIVER</th>
              {!simplified && <th className="px-2 py-2 text-right">GAP</th>}
              <th className="px-2 py-2 text-right">INT</th>
              {!simplified && <th className="px-2 py-2 text-center">TYRE</th>}
              {!simplified && <th className="px-2 py-2 text-center">PITS</th>}
              <th className="px-2 py-2 text-center">DELTA</th>
            </tr>
          </thead>
          <tbody>
            {drivers.map((driver) => (
              <tr
                key={driver.id}
                onClick={() => onDriverSelect(driver)}
                onMouseEnter={() => setHoveredDriver(driver.id)}
                onMouseLeave={() => setHoveredDriver(null)}
                className={cn(
                  'cursor-pointer transition-all duration-200 border-b border-border/50',
                  selectedDriverId === driver.id && 'bg-primary/20 border-glow-red',
                  hoveredDriver === driver.id && selectedDriverId !== driver.id && 'bg-muted/50'
                )}
              >
                <td className="px-2 py-2">
                  <span className={cn(
                    'font-mono font-bold text-lg',
                    driver.position === 1 && 'text-f1-yellow',
                    driver.position === 2 && 'text-foreground',
                    driver.position === 3 && 'text-f1-orange',
                    driver.position > 3 && 'text-muted-foreground'
                  )}>
                    P{driver.position}
                  </span>
                </td>
                <td className="px-2 py-2">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-1 h-6 rounded-full"
                      style={{ backgroundColor: driver.teamColor }}
                    />
                    <div className="flex flex-col">
                      <span className="font-bold text-sm">{driver.code}</span>
                      <span className="text-xs text-muted-foreground">{driver.team}</span>
                    </div>
                  </div>
                </td>
                {!simplified && (
                  <td className="px-2 py-2 text-right">
                    <span className={cn(
                      'font-mono text-sm',
                      driver.gap === 'LEADER' ? 'text-f1-cyan font-bold' : 'text-muted-foreground'
                    )}>
                      {driver.gap}
                    </span>
                  </td>
                )}
                <td className="px-2 py-2 text-right">
                  <span className="font-mono text-sm text-foreground">{driver.interval}</span>
                </td>
                {!simplified && (
                  <td className="px-2 py-2">
                    <div className="flex justify-center">
                      <TyreIndicator compound={driver.tyre} age={driver.tyreAge} />
                    </div>
                  </td>
                )}
                {!simplified && (
                  <td className="px-2 py-2 text-center">
                    <span className="font-mono text-sm text-muted-foreground">{driver.pits}</span>
                  </td>
                )}
                <td className="px-2 py-2">
                  <div className="flex justify-center">
                    <DeltaIndicator delta={driver.delta} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
